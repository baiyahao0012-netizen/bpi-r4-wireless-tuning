# dscpstats.awk - aggregate mac80211:wifi_dscp trace events for dscpstats(1)
#
# Input lines (from trace_pipe), e.g.:
#   ... wifi_dscp: dir=0 stage=0 dscp=0x88 len=1400 skb=0x... ts=... acked=0 retry=0
#
# Stages: 0=ENQ 1=DEQ 2=ACK 3=RX. TX packets are correlated by the skb key.
# "dscp" is the IP ToS byte with ECN masked (0x88, 0xa0, ...). ACK events
# carry dscp=0; the real value is recovered from the matching ENQ event.
# "retry" (ACK stage, else 0) is the number of MAC-layer TX retries mac80211
# accounted for the frame; aggregated per DSCP as retp (frames with retry>0),
# rets (sum of retries) and retm (max retries on a frame).

function flush(    d, tf) {
	tf = out ".tmp"
	printf "" > tf
	for (d in seen)
		printf "%s %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f %.0f\n", \
			d, pkts[d], bytes[d], \
			qcnt[d], qsum[d], qmin[d], qmax[d], \
			ecnt[d], esum[d], emin[d], emax[d], \
			acnt[d], asum[d], amin[d], amax[d], \
			ack[d], fail[d], rpkts[d], rbytes[d], \
			retp[d], rets[d], retm[d] >> tf
	close(tf)
	system("mv -f " tf " " out)
}

BEGIN { n = 0 }

{
	# drop the trace header, keep only the event payload
	sub(/^.*wifi_dscp: /, "")

	delete kv
	for (i = 1; i <= NF; i++) {
		if (index($i, "=") == 0)
			continue
		split($i, p, "=")
		kv[p[1]] = p[2]
	}

	stage = kv["stage"] + 0
	dscp  = kv["dscp"]
	len   = kv["len"] + 0
	skb   = kv["skb"]
	ts    = kv["ts"] + 0
	ackf  = kv["acked"] + 0

	if (dscp == "" || skb == "")
		next

	if (stage == 0) {			# ENQ
		enq[skb] = ts
		edscp[skb] = dscp
		seen[dscp] = 1
		pkts[dscp]++
		bytes[dscp] += len
	} else if (stage == 1) {		# DEQ
		if (!(skb in enq))
			next
		q = ts - enq[skb]
		qlat[skb] = q
		seen[dscp] = 1
		if (qcnt[dscp]++ == 0 || q < qmin[dscp]) qmin[dscp] = q
		if (q > qmax[dscp]) qmax[dscp] = q
		qsum[dscp] += q
	} else if (stage == 2) {		# ACK
		if (!(skb in enq))
			next
		d = edscp[skb]
		e2e = ts - enq[skb]
		seen[d] = 1
		retry = kv["retry"] + 0		# ACK stage only; TX retries of this frame
		if (retry > 0) retp[d]++
		if (retry > retm[d]) retm[d] = retry
		rets[d] += retry
		if (ackf) {
			if (ecnt[d]++ == 0 || e2e < emin[d]) emin[d] = e2e
			if (e2e > emax[d]) emax[d] = e2e
			esum[d] += e2e
			if (skb in qlat) {
				acc = e2e - qlat[skb]
				if (acnt[d]++ == 0 || acc < amin[d]) amin[d] = acc
				if (acc > amax[d]) amax[d] = acc
				asum[d] += acc
			}
			ack[d]++
		} else {
			fail[d]++
		}
		delete enq[skb]
		delete edscp[skb]
		delete qlat[skb]
	} else if (stage == 3) {		# RX
		seen[dscp] = 1
		rpkts[dscp]++
		rbytes[dscp] += len
	}

	n++
	if (n % 4096 == 0 || systime() != last) {
		flush()
		last = systime()
	}
}

END { flush() }
