#!/bin/sh
# Hot-reload mac80211 with a newly copied module. Runs detached so it
# completes even if the management link drops (e.g. Wi-Fi-only SSH).
exec >/tmp/reload.log 2>&1
echo "reload start $(date)"

cp -f /root/mac80211.ko.new /lib/modules/6.6.151/mac80211.ko || echo "copy failed"
sync

wifi down
sleep 2

for m in mt7996e mt76_connac_lib mt76 mac80211; do
	rmmod "$m" && echo "rmmod $m ok" || echo "rmmod $m FAIL"
done

modprobe mac80211 && echo "modprobe mac80211 ok" || echo "modprobe mac80211 FAIL"
modprobe mt76 && echo "modprobe mt76 ok" || echo "modprobe mt76 FAIL"
modprobe mt76_connac_lib && echo "modprobe connac ok" || echo "modprobe connac FAIL"
modprobe mt7996e && echo "modprobe mt7996e ok" || echo "modprobe mt7996e FAIL"

sleep 3
wifi up
sleep 5
echo "reload done $(date)"
lsmod | grep -E 'mac80211|mt7996e'
