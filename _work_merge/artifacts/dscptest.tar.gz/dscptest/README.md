# Wi‑Fi DSCP 时延/吞吐/重传统计（backports-src）

在 **mac80211 内核**里埋一个 tracepoint，按 **DSCP** 记录每个 Wi‑Fi 包的发送/接收时刻；
用户态用 `awk` 把同一个包的各阶段关联起来，算出每档 DSCP 的**时延**、**吞吐**（包数/字节）
与 **TX 重传率**。

- **目标平台**：ImmortalWrt / OpenWrt 24.10，BPI‑R4（MediaTek MT7996，Wi‑Fi 7）
- **内核侧**：两个补丁
  - `354-wifi-mac80211-add-dscp-latency-tracepoint.patch` —— mac80211 埋点（含 per-frame `retry` 字段），只改 5 个已存在文件
  - `355-wifi-mt76-mt7996-report-tx-retries.patch` —— mt76 驱动上报真实 TX 尝试次数（**重传率依赖它**）
- **用户态**：`dscpstats`（入口脚本）+ `dscpstats.awk`（聚合器），只依赖 tracefs 与 `awk`
- **状态**：TX 全链路（ENQ→DEQ→ACK）、RX、以及 **TX 重传率**均已上机验证
  （2.4G legacy + 5G Wi‑Fi 6 HE80）

---

## 1. 它做什么

一个事件流 + 一张报表：

```
内核 (mac80211)                                用户态
  发包 ─ txq_enqueue ── ENQ ─┐
        tx_dequeue  ── DEQ ─┤   tracepoint   ──►  trace_pipe  ──►  awk 聚合  ──►  /tmp/dscpstats.state
        report_used_skb ACK ┘   wifi_dscp                              │             (每 DSCP 一行)
  收包 ─ rx_8023/rx_h_data RX ─┘                                       ▼
                                                                  dscpstats status / stop
```

- **只统计 8 个目标 DSCP**（其余 DSCP 不产生事件，不占 trace 带宽）：

  | 事件值 | DSCP | 业务名 |
  |---|---|---|
  | `0x88` | AF41 | video-call-media |
  | `0xa0` | CS5  | video-call-signal |
  | `0x80` | CS4  | gaming |
  | `0x68` | AF31 | video-streaming |
  | `0x48` | AF21 | browsing |
  | `0x30` | AF12 | file-upload |
  | `0x28` | AF11 | email |
  | `0x20` | CS1  | background |

- **时延**（TX，单位 us）：`queue` = ENQ→DEQ，`access` = DEQ→ACK，`e2e` = ENQ→ACK。
- **吞吐**：每个 DSCP 的包数/字节数；另有 RX 方向的包数/字节数（只计数，不算时延）。
- **重传**（TX，来自 ACK 阶段的 `retry`）：`retryP` 发生重传的帧数、`reAvg` 平均重传次数/帧、
  `reMax` 单帧最大重传次数、`re%` 重传率。
- 事件字段：`dir, stage, dscp, len, skb, ts, acked, retry`
  （`dir`：0=TX, 1=RX；`stage`：0=ENQ, 1=DEQ, 2=ACK, 3=RX；`retry` 仅 ACK 阶段非 0，其余阶段为 0）。

> 口径说明见 §7：本平台统计的是 **MSDU / IP goodput**，不是 MPDU/空口吞吐。

---

## 2. 目录内容

| 文件 / 目录 | 说明 |
|---|---|
| `354-wifi-mac80211-add-dscp-latency-tracepoint.patch` | mac80211 补丁，**权威副本**。放到 `openwrt/package/kernel/mac80211/patches/subsys/` |
| `355-wifi-mt76-mt7996-report-tx-retries.patch` | mt76 驱动补丁（上报真实 TX 尝试次数，重传率依赖它）。放到 `openwrt/package/kernel/mt76/patches/` |
| `backports-6.12.96/` | 打过补丁的 backports 参考源码树（改动写在这里，查阅/生成补丁用，**不参与构建**） |
| `dscpstats` | 用户态入口脚本：`start \| stop \| status \| help` |
| `dscpstats.awk` | 聚合器（按 skb 关联同一包的 TX 三阶段） |
| `test/` | 纯软件测试（L2 awk golden + L3 shell 管线仿真），`sh test/run_tests.sh` |
| `REQUIREMENTS.md` / `LINUX_TUTORIAL.md` | 需求设计与实测明细 / Linux 学习教程 |

用户态找事件的路径：`events/mac80211/wifi_dscp`，tracefs 在
`/sys/kernel/tracing` 或 `/sys/kernel/debug/tracing`。

---

## 3. 内核改动一览

mac80211 补丁只动这 **5 个已存在文件**、共 **16 个 hunk**，不新增文件、不改 Makefile；
另有**独立**的 mt76 驱动补丁 `355-*`（见 §3.7，重传率依赖它）。概览：

| 文件 | 动了哪些函数 |
|---|---|
| `net/mac80211/ieee80211_i.h` | 新增公共枚举 + 3 个 `static inline`（DSCP 匹配 + eth/80211 两个解析器） |
| `net/mac80211/trace.h` | 新增 `TRACE_EVENT(wifi_dscp, …)` |
| `net/mac80211/tx.c` | `ieee80211_txq_enqueue`（ENQ）、`ieee80211_tx_dequeue`（DEQ） |
| `net/mac80211/status.c` | `ieee80211_report_used_skb`（ACK） |
| `net/mac80211/rx.c` | `ieee80211_rx_8023`（快路）、`ieee80211_rx_h_data`（慢路兜底） |

下面逐文件列出**具体改了什么**（`+` 表示新增）。行号是补丁 hunk 的上下文，实际位置以 patch 为准。

### 3.1 `ieee80211_i.h`（提供公共定义）

1. 加两个头（供解析器用）：
   ```c
   +#include <linux/if_vlan.h>
   +#include <linux/ip.h>
   ```
2. 在 `IEEE80211_MAX_NAN_INSTANCE_ID` 之后新增枚举：`dir` 用 `DIR_` 前缀，避免与 `stage` 的 `WIFI_DSCP_RX` 重名。
   ```c
   +enum wifi_dscp_dir   { WIFI_DSCP_DIR_TX = 0, WIFI_DSCP_DIR_RX };
   +enum wifi_dscp_stage { WIFI_DSCP_ENQ = 0, WIFI_DSCP_DEQ, WIFI_DSCP_ACK, WIFI_DSCP_RX };
   ```
3. 新增三个 `static inline`：
   - `ieee80211_wifi_dscp_match(u8 tos)`：`switch (tos & 0xfc)`，命中 8 个目标 DSCP 返回 `true`。
   - `ieee80211_wifi_dscp_eth(skb)`：读以太头 → 处理 `ETH_P_8021Q/8021AD` VLAN → `ETH_P_IP` → 读 `ip.tos`；
     返回 `ip.tos & 0xfc`，否则 `-1`。
   - `ieee80211_wifi_dscp_80211(skb)`：读 `fc` → `ieee80211_is_data()` → `ieee80211_hdrlen()` →
     LLC/SNAP `RFC1042 + ETH_P_IP` → 读 `ip.tos`；返回 `tos & 0xfc`，否则 `-1`。
   全部用 `skb_copy_bits()`，支持非线性 skb、越界返回 `-1`。

### 3.2 `trace.h`（定义事件）

在文件末尾（`#endif /* !__MAC80211_DRIVER_TRACE … */` 之前）追加：

```c
+TRACE_EVENT(wifi_dscp,
+	TP_PROTO(u8 dir, u8 stage, u8 dscp, u16 len,
+		 const void *skb, u64 ts, u8 acked, u8 retry),
+	TP_ARGS(dir, stage, dscp, len, skb, ts, acked, retry),
+	TP_STRUCT__entry(
+		__field(u8, dir)   __field(u8, stage) __field(u8, dscp)
+		__field(u16, len)  __field(const void *, skb)
+		__field(u64, ts)   __field(u8, acked) __field(u8, retry)),
+	TP_fast_assign(/* 逐个赋值 */),
+	TP_printk("dir=%u stage=%u dscp=0x%02x len=%u skb=%p ts=%llu acked=%u retry=%u", …)
+);
```

四个阶段共用这一个事件（靠 `dir/stage` 区分），所以一个 tracefs 开关控制整个测量窗口。
`retry` 是新增字段：**仅 ACK 阶段有意义**（每帧的 MAC 层重传次数），ENQ/DEQ/RX 传 0。

### 3.3 `tx.c`（TX 两个阶段）

1. 加头：`#include <linux/timekeeping.h>`（用 `ktime_get_ns`）。
2. `ieee80211_txq_enqueue()`：在 `ieee80211_set_skb_enqueue_time(skb)` 之后、拿 `fq->lock` 之前插入 **ENQ**：
   ```c
   +if (trace_wifi_dscp_enabled()) {
   +	int dscp = (IEEE80211_SKB_CB(skb)->flags & IEEE80211_TX_CTL_HW_80211_ENCAP) ?
   +		ieee80211_wifi_dscp_eth(skb) : ieee80211_wifi_dscp_80211(skb);
   +	if (dscp >= 0) {
   +		IEEE80211_SKB_CB(skb)->flags |= IEEE80211_TX_CTL_REQ_TX_STATUS; /* 让驱动逐帧回报 ACK */
   +		trace_wifi_dscp(WIFI_DSCP_DIR_TX, WIFI_DSCP_ENQ, dscp, skb->len, skb, ktime_get_ns(), 0, 0);
   +	}
   +}
   ```
   按 `HW_80211_ENCAP` 选择解析器；命中才置 `REQ_TX_STATUS`，避免给无关帧带来开销。
3. `ieee80211_tx_dequeue()`：在 `spin_unlock_bh(&fq->lock)` 之后插入 **DEQ**，同样选解析器、发事件
   （不加 `REQ_TX_STATUS`）。

### 3.4 `status.c`（ACK 阶段）

1. 加头：`<linux/timekeeping.h>`、`"driver-ops.h"`。
2. `ieee80211_report_used_skb()`：**加一个 `int retry_count` 形参**，在算出 `acked` 之后、
   `if (tx_time_est)` 之前插入 **ACK**：
   ```c
   +if (trace_wifi_dscp_enabled() && skb->len >= sizeof(__le16) &&
   +    ((info->flags & IEEE80211_TX_CTL_HW_80211_ENCAP) || ieee80211_is_data(hdr->frame_control)))
   +	trace_wifi_dscp(WIFI_DSCP_DIR_TX, WIFI_DSCP_ACK, 0, skb->len, skb,
   +			ktime_get_ns(), acked, (u8)min_t(int, retry_count, U8_MAX));
   ```
   此处 payload 已加密、无法再解析 DSCP，所以 `dscp=0`，由用户态按 `skb` 从 ENQ 事件回填。
   `retry_count` 是 mac80211 现成的 per-frame 重传数（`ieee80211_tx_get_rates()`），
   由 3 个调用点传入：`__ieee80211_tx_status()` / `tx_status_ext` 的 free 分支传 `retry_count`，
   `ieee80211_free_txskb()`（丢包）传 0；并在 `tx_status_ext` 里把声明初始化为 `0`
   （避免 `!status->info` 走 free 时用到未初始化值）。

### 3.5 `rx.c`（RX 两个路径）

1. 加头：`#include <linux/timekeeping.h>`。
2. `ieee80211_rx_h_data()`：在 `res != RX_CONTINUE` 分支之后插入 **RX（慢路径兜底）**：
   ```c
   +if (trace_wifi_dscp_enabled()) {
   +	int dscp = ieee80211_wifi_dscp_eth(rx->skb);
   +	if (dscp >= 0)
   +		trace_wifi_dscp(WIFI_DSCP_DIR_RX, WIFI_DSCP_RX, dscp, rx->skb->len, rx->skb, ktime_get_ns(), 0, 0);
   +}
   ```
3. `ieee80211_rx_8023()`：在 `u64_stats_update_end()` 之后插入 **RX（快路径）**，同上（用 `skb`）。
   RX 只统计包/字节、不算时延。两条路径互斥（fast‑rx/decap‑offload 命中就不再进慢路径），不会重复计数。

### 3.6 DSCP 怎么识别（示意图）

识别分两步：**先把 IP 的 ToS 字节取出来，再看它是不是 8 个目标值之一**。

**① 值怎么定**——IP 头里的 `tos` 字节 = 高 6 位 DSCP + 低 2 位 ECN；代码掩掉 ECN，用 `tos & 0xfc`：

```
 IP ToS 字节 (8bit):   ┌── DSCP 6bit ──┐┌ECN 2bit┐
                       0  1 0 0 0 1    0   0
 AF41 = DSCP 34 = 0b100010  →  ToS = 0x88  →  & 0xfc  →  事件里 dscp=0x88
```

匹配就是 `switch (tos & 0xfc)`，命中 8 个之一才返回该值并发事件，否则返回 `-1`（不发）。

**② 从帧里怎么找到 IP 头**——两种封装各一个解析器：

```
 802.3 / 以太帧  →  ieee80211_wifi_dscp_eth()
 ┌───────────────┬───────────────┬───────────────┬─────────┐
 │ 以太头 14B     │ VLAN 4B (可选) │ IPv4 头 20B+   │ payload │
 │ dst6 src6 etype│ 0x8100/0x88a8 │ ver.. tos ..   │         │
 └───────────────┴───────────────┴───────┬───────┴─────────┘
                                         └──► 读 ip.tos

 802.11 帧  →  ieee80211_wifi_dscp_80211()
 ┌──────────────────┬───────────────┬───────────────┬─────────┐
 │ 802.11 MAC 头     │ LLC/SNAP 8B   │ IPv4 头 20B+   │ payload │
 │ len=ieee80211_    │ AA AA 03 00   │ ver.. tos ..   │         │
 │   hdrlen(fc)      │ 00 00 <etype> │                │         │
 └──────────────────┴───────────────┴───────┬───────┴─────────┘
                                            └──► 读 ip.tos
```

两者都用 `skb_copy_bits()`（支持非线性 skb，越界返回 `-1`），都只认 **IPv4**。

**③ 为什么 RX 用 802.3、TX 可能用 802.11**——埋点所处的位置不同：

```
 RX (mac80211 收包)
   驱动送 802.11 帧
        │
        ├── fast-rx / decap-offload 命中 ─────────► 802.3 帧 ┐
        │                                                    ├─► 埋点 RX（eth 解析器）─► 协议栈 / wlan0
        └── 未命中 → __ieee80211_data_to_8023() ───► 802.3 帧 ┘
                     （802.11 → 802.3 转换）

 TX (mac80211 发包)
   协议栈 ─► ENQ：skb 什么形态？
               ├ HW_80211_ENCAP 置位 → 已是 802.3  → eth   解析器 ─► ENQ 事件
               └ 未置位             → 仍是 802.11 → 80211 解析器 ─► ENQ 事件
            ─► DEQ（同规则选解析器）─► 驱动/固件封装成 802.11 发出
                                          └─► 收到 ACK：payload 已加密 → ACK 事件 dscp=0（用户态按 skb 回填）
```

要点：RX 埋点都在 `802.11 → 802.3` 转换**之后**（慢路 `ieee80211_rx_h_data` 里先调 `__ieee80211_data_to_8023()` 再埋点；快路 `ieee80211_rx_8023` 的帧本就是以以太地址开头），所以那里 skb 一定是以太帧、天然用 `eth` 解析器。要做到这点是因为 mt7996 走 fast‑rx/decap‑offload，绕过普通转换函数，只有 802.3 侧才覆盖得到。

> RX 为什么有两处、以及 fast‑rx / decap‑offload 的来龙去脉，见 §6.1。
> **想从头手动复现一遍**（改内核 → 生成补丁 → 编译 → 部署 → 跑 `dscpstats`），直接看 §4。

### 3.7 mt76 驱动补丁 `355`（重传率的关键）

mac80211 的 per-frame `retry_count` 来自 **legacy** `info->status.rates[].count`
（`ieee80211_tx_get_rates()`）。但 mt7996（OpenWrt 的 mt76 包，2025‑11‑06）走**新式 rate 上报**
（`status->rates[]`），**从不填 legacy `count`**，所以 mac80211 侧 retry 恒 0。
更麻烦的是 `struct ieee80211_tx_info` 里 **`control.rates` 与 `status.rates` 是同一个 union**：
失败帧走释放路径没被清 → 残留 rate-control 的档数 → mac80211 误算出 `retry=1`；
实测表现为 `iw station dump` 的 `tx retries` 与 `tx failed` **同步增长**（不是真实重传）。

**修复**：在 `mt7996_mac_add_txs_skb()` 的 MPDU TXS 分支里用硬件字段回填。

| 文件 | 函数 | 改动 |
|---|---|---|
| `mt7996/mac.c` | `mt7996_mac_add_txs_skb` | `info->status.rates[0].idx = -1;` → 置有效 `idx` 并用 `MT_TXS5_F0_TX_COUNT`（实际发送次数）填 `count` |

```c
-			info->status.rates[0].idx = -1;
+			info->status.rates[0].idx = 0;
+			info->status.rates[0].count =
+				FIELD_GET(MT_TXS5_F0_TX_COUNT, txs_data[5]);   /* = 实际尝试次数 */
```

mac80211 侧 `retry = count - 1`，所以填「尝试次数」即可。补丁路径前缀 `a/`、`-p1`，
与 mt76 包现有补丁一致（放到 `openwrt/package/kernel/mt76/patches/`）。

> **只改 mac80211 不行**：本平台实测 mac80211-only 的 retry 恒 0（见 §8.4）。驱动补丁是重传率的前提。
> 改动只影响 `kmod-mt7996e` → 换 `mt7996e.ko` + 重启（无需刷机，见 §8.2）。

---

## 4. 端到端复现（改内核 → 跑 dscpstats）

从修改 mac80211 到在路由器上运行 `dscpstats` 的完整手动流程。
以下命令都在仓库根 `/home/sean/openwrt_mod` 下执行（OpenWrt 源码树是 `./openwrt`）。

**有两条路**，区别只在「内核改动放哪、编译带不带 `clean`」：

| | 方法② 用补丁（正规，4.1–4.7） | 方法① 不用补丁（快，§4.8） |
|---|---|---|
| 改哪里 | 参考树 `backports-src/backports-6.12.96/` | 构建目录 `openwrt/build_dir/…/backports-6.12.96/` |
| 编译 | `make … **clean** compile` | `make … compile`（**不 clean**） |
| 结果 | 可复现/可交付，`clean` 后仍在 | 一次性调试，`clean`/换机器即丢 |

**下面 4.1–4.7 是方法②（推荐）**；不想碰补丁、只想快速试，直接跳到 **§4.8**。

```
方法②（补丁）  4.1 改参考树 → 4.2 生成补丁 → 4.3 放入补丁 → 4.4 配置
                → 4.5 clean 编译 → 4.6 换 .ko + 重启 → 4.7 装脚本 + 运行

方法①（免补丁）§4.8 直改构建目录 → 不 clean 编译 → 换 .ko + 重启 → 装脚本 + 运行
```

### 4.1 改内核源码（改动写在「参考树」）

**mac80211** 改动写在参考树 `backports-src/backports-6.12.96/`，涉及这 5 个文件（内容见 §3）：

```
net/mac80211/ieee80211_i.h   net/mac80211/trace.h   net/mac80211/tx.c
net/mac80211/status.c        net/mac80211/rx.c
```

```sh
$EDITOR backports-src/backports-6.12.96/net/mac80211/rx.c
```

参考树**不参与构建**：它只是「改动的真相来源」，用来生成补丁和留档。
改完就去 §4.2 把它变成补丁。

**mt76 驱动**没有单独的参考树（源码是 OpenWrt 自己的 git 包）。改动很小（§3.7 一处），
直接维护成补丁 `355-wifi-mt76-mt7996-report-tx-retries.patch`；生成方式：在 mt76 包源码里
改好 `mt7996/mac.c` 后 `diff -u`（前缀 `a/`/`b/`），或直接改构建目录再 `diff`（见 §4.2 末）。

> 若只想快速试一下、不想走完整流程，也可以直接改 OpenWrt 构建目录里的源码
> （**§4.8 方法①**），但那属于一次性调试，`clean` 后改动会丢、不可复现。

### 4.2 生成补丁（补丁是怎么产生的）

**补丁 = 「pristine 基线」对「参考树」的 diff，再拼上提交信息头。** 三个角色：

| 角色 | 路径 | 说明 |
|---|---|---|
| 基线 | `openwrt/dl/backports-6.12.96.tar.zst` | OpenWrt 下载的上游 pristine 源码（= backports-v6.12.96 / commit `d43b2b8`） |
| 参考树 | `backports-src/backports-6.12.96/` | 你在 §4.1 改好的那 5 个文件 |
| 输出① | `backports-src/354-wifi-mac80211-add-dscp-latency-tracepoint.patch` | mac80211 补丁，交给 OpenWrt 应用 |
| 输出② | `backports-src/355-wifi-mt76-mt7996-report-tx-retries.patch` | mt76 驱动补丁（生成方式见本节末） |

生成命令（把基线解压成临时 git 仓库，用参考树覆盖 5 个文件，再 `git diff`）：

```sh
export PATH=/home/sean/openwrt_mod/openwrt/staging_dir/host/bin:$PATH   # 提供 zstd
rm -rf /tmp/patchgen && mkdir -p /tmp/patchgen && cd /tmp/patchgen
tar --zstd -xf /home/sean/openwrt_mod/openwrt/dl/backports-6.12.96.tar.zst
cd backports-6.12.96

# 1) 把基线变成一个临时 git 仓库，便于 diff
git init -q && git add -A && git -c user.email=a@b -c user.name=a commit -qm pristine

# 2) 用参考树的 5 个文件覆盖基线
SRC=/home/sean/openwrt_mod/backports-src/backports-6.12.96
for f in net/mac80211/ieee80211_i.h net/mac80211/trace.h net/mac80211/tx.c \
         net/mac80211/status.c net/mac80211/rx.c; do
  cp "$SRC/$f" "$f"
done

# 3) git diff 出正文，前面拼上「提交信息头」（复用旧补丁的头 22 行）
git diff > /tmp/body
head -22 /home/sean/openwrt_mod/backports-src/354-wifi-mac80211-add-dscp-latency-tracepoint.patch > /tmp/header
cat /tmp/header /tmp/body > /home/sean/openwrt_mod/backports-src/354-wifi-mac80211-add-dscp-latency-tracepoint.patch
```

- **提交信息头**就是补丁最开头那 22 行（`From/Date/Subject/.../Signed-off-by` + `---`）。
  首次生成时先准备一个：可从现有补丁复制，或按 `git format-patch` 的格式手写。
- **校验**（可复现性的关键）：
  ```sh
  cd /tmp/patchgen/backports-6.12.96 && git checkout -q . && \
    patch -p1 --dry-run < /home/sean/openwrt_mod/backports-src/354-*.patch   # 期望干净通过、无 fuzz
  grep -c '^@@' /home/sean/openwrt_mod/backports-src/354-*.patch              # 期望 16
  ```
  再校验「回放结果 == 参考树」：`git apply` 后与前缀无关地 `diff` 那 5 个文件应完全一致。
- 本流程天然只 diff 那 5 个文件；补丁里**不要**含调试 `printk`（`RXDBG`/`WIFDBG`）；
  `index` 行哈希每次生成都会变，属正常。
- **改代码就改参考树、再按本节重新生成补丁；不要手改补丁**（易错）。

**生成 `355`（mt76）**——驱动补丁是独立的一小段，直接对 mt76 包源码 diff（前缀 `a/`/`b/`）：

```sh
D=openwrt/build_dir/target-aarch64_cortex-a53_musl/linux-mediatek_filogic/mt76-2025.11.06~eb567bc7
cp "$D/mt7996/mac.c" /tmp/mac.c.orig
$EDITOR "$D/mt7996/mac.c"                                   # 按 §3.7 改
diff -u --label a/mt7996/mac.c --label b/mt7996/mac.c \
        /tmp/mac.c.orig "$D/mt7996/mac.c" > backports-src/355-wifi-mt76-mt7996-report-tx-retries.patch
cp /tmp/mac.c.orig "$D/mt7996/mac.c"                        # 还原（构建时会按补丁重放）
cd "$D" && patch -p1 --dry-run < /home/sean/openwrt_mod/backports-src/355-*.patch   # 期望干净通过
```

> 生成后**同步生效副本**：mac80211 → `openwrt/package/kernel/mac80211/patches/subsys/`；
> mt76 → `openwrt/package/kernel/mt76/patches/`。
>
> 补丁生成是一次性（或改代码时才做）的动作，**不是每次构建都要跑**；日常构建只是复用它（§4.3）。

### 4.3 放入补丁

```sh
cp backports-src/354-wifi-mac80211-add-dscp-latency-tracepoint.patch \
   openwrt/package/kernel/mac80211/patches/subsys/
cp backports-src/355-wifi-mt76-mt7996-report-tx-retries.patch \
   openwrt/package/kernel/mt76/patches/
```

**补丁是构建的必需输入**：OpenWrt 编 mac80211 时 `Build/Prepare` = 解压 pristine tarball
(`$(PKG_UNPACK)`) + 重放补丁 (`$(Build/Patch)` → `patches/subsys/*.patch`，见该包 Makefile 304/342 行)。
所以 `clean` 重编、换机器、全量、交付**都必须有它**；只有「直改 build_dir 且不 clean」的
一次性调试可以没有（**§4.8 方法①**）。

> 补丁各有两份副本，**必须保持一致**：
> `backports-src/354-*.patch` ↔ `openwrt/package/kernel/mac80211/patches/subsys/354-*.patch`；
> `backports-src/355-*.patch` ↔ `openwrt/package/kernel/mt76/patches/355-*.patch`。
> 前者是权威/交付用，后者才是真正生效的。

### 4.4 配置（BPI‑R4）

```sh
cd openwrt
./scripts/feeds update -a && ./scripts/feeds install -a
cat > .config <<'EOF'
CONFIG_TARGET_mediatek=y
CONFIG_TARGET_mediatek_filogic=y
CONFIG_TARGET_mediatek_filogic_DEVICE_bananapi_bpi-r4=y
CONFIG_PACKAGE_kmod-mac80211=y
CONFIG_PACKAGE_MAC80211_TRACING=y
EOF
make defconfig
```

`MAC80211_TRACING=y` 必开：它会 select `KERNEL_FTRACE` /
`KERNEL_ENABLE_DEFAULT_TRACERS`，否则 tracefs 里根本不会有 `wifi_dscp` 事件。

### 4.5 编译内核模块（mac80211 / mt76）

```sh
cd /home/sean/openwrt_mod/openwrt
make package/kernel/mac80211/clean package/kernel/mac80211/compile V=s   # mac80211 补丁
make package/kernel/mt76/clean      package/kernel/mt76/compile      V=s   # mt76 驱动补丁
```

产物（未 strip）：
```
build_dir/target-*/linux-mediatek_filogic/mac80211-regular/backports-6.12.96/net/mac80211/mac80211.ko
build_dir/target-*/linux-mediatek_filogic/mt76-2025.11.06~eb567bc7/mt7996/mt7996e.ko
```

> 带 `clean` 会**重新解压 pristine + 重放补丁**，所以真相来源必须是 patch。
> 只改构建目录里的源码而不回写 patch，`clean` 后就会丢。
> 每个包编译很快（本机约 1～1.5 分钟）。

### 4.6 换 `.ko` + 重启

要拿到重传率需要**同时**换 `mac80211.ko` 和 `mt7996e.ko`（mac80211-only 的 retry 恒 0，见 §3.7）。

```sh
cd /home/sean/openwrt_mod/openwrt
M=build_dir/target-aarch64_cortex-a53_musl/linux-mediatek_filogic/mac80211-regular/backports-6.12.96/net/mac80211/mac80211.ko
T=build_dir/target-aarch64_cortex-a53_musl/linux-mediatek_filogic/mt76-2025.11.06~eb567bc7/mt7996/mt7996e.ko

modinfo "$M" "$T" | grep vermagic     # 期望: 6.6.151 SMP mod_unload aarch64
ssh root@<router> uname -r            # 期望: 6.6.151（与上面一致才能换）

scp "$M" root@<router>:/tmp/mac80211.ko
scp "$T" root@<router>:/tmp/mt7996e.ko
ssh root@<router> 'K=$(uname -r)
  cp /lib/modules/$K/mac80211.ko /lib/modules/$K/mac80211.ko.bak
  cp /lib/modules/$K/mt7996e.ko  /lib/modules/$K/mt7996e.ko.bak
  cp /tmp/mac80211.ko /lib/modules/$K/mac80211.ko
  cp /tmp/mt7996e.ko  /lib/modules/$K/mt7996e.ko; reboot'

# 重启后确认模块已更新、事件已出现
ssh root@<router> 'K=$(uname -r); sha256sum /lib/modules/$K/{mac80211,mt7996e}.ko'  # 与本机产物对比
ssh root@<router> 'ls /sys/kernel/debug/tracing/events/mac80211/wifi_dscp'
```

> 只能「换文件 + 重启」，**不能** `rmmod mac80211`/`mt7996e` 热重载（mt7996 固件会崩）。
> 用 ipk 安装、或想判断该不该全量刷机，见 §5.3 与 §8.2。

### 4.7 部署脚本并运行 `dscpstats`

```sh
scp backports-src/dscpstats backports-src/dscpstats.awk root@<router>:/root/
ssh root@<router> chmod +x /root/dscpstats

ssh root@<router> 'mount -t tracefs tracefs /sys/kernel/debug/tracing 2>/dev/null; /root/dscpstats start'
# ... 产生带 DSCP 的流量（见 §5.1）...
ssh root@<router> /root/dscpstats status     # 随时看实时累计
ssh root@<router> /root/dscpstats stop       # 结束并打印最终报表
```

到这里端到端就通了：补丁进了内核 → 事件出现在 tracefs → 报表出来。
报表列含义见 §5.6；命令细节见 §5.4。

### 4.8 方法①：不用补丁（直接改构建目录）

不想生成/维护补丁、只想本机快速调试时走这条。机制一句话：

> **`clean` 会删掉构建源码、重新解压 + 重放补丁；不 `clean` 就直接用现成目录编译，手改就留下了。**

```sh
cd /home/sean/openwrt_mod/openwrt
D=build_dir/target-aarch64_cortex-a53_musl/linux-mediatek_filogic/mac80211-regular/backports-6.12.96

# 1) 直接改构建目录里的源码（不碰补丁、不碰参考树）
$EDITOR $D/net/mac80211/rx.c

# 2) 只编译 —— 关键：绝对不要带 clean
make package/kernel/mac80211/compile V=s

# 3) 产物（之后照 §4.6 换 .ko + 重启、§4.7 装脚本运行）
ls -l $D/net/mac80211/mac80211.ko
```

- **绝对不能 `clean`**：一旦 `make package/kernel/mac80211/clean`（或全量重编），
  `build_dir` 被重建、手改全丢。
- 不可复现、不可交付、换机器即失。改动确定后请回到方法② 把它固化成补丁。
- 「有补丁」和「有手改」不冲突：**补丁是 `clean` 后重建的备份，手改是当前 `build_dir` 的实际内容**，
  两者可以不一致。例如本机现在的 `build_dir` 手改里就带着调试 `RXDBG`，而干净补丁里没有。
  设备上正在跑的模块正是这份手改产物（sha256 与本机 `build_dir` 产物一致）。

---

## 5. 用户手册：`dscpstats`

> 本节即原 `USAGE.md`，已合并于此。文中 `<router>` 指路由器地址（如 `192.168.1.1`）。
> 建议**管理走网线**，避免切频/重启掉 SSH。

### 5.1 前置条件

1. **mac80211 补丁已生效**：设备上存在 `wifi_dscp` 事件（且 `format` 里有 `retry` 字段）
   ```sh
   ls /sys/kernel/debug/tracing/events/mac80211/wifi_dscp          # 或 /sys/kernel/tracing/...
   grep -c retry /sys/kernel/debug/tracing/events/mac80211/wifi_dscp/format   # retry 版本应 >=1
   ```
   没有 → mac80211 补丁没编进去（见 §4）。
2. **（重传率必需）mt76 驱动补丁已生效**：`mt7996e.ko` 是带 `355` 补丁的版本。
   没有 → 时延/吞吐正常，但 `retryP/reAvg/reMax/re%` 恒为 0（见 §3.7）。
3. **tracefs 已挂载**：`mount | grep tracefs`；未挂载则
   `mount -t tracefs tracefs /sys/kernel/debug/tracing`。
4. 用户态只需 **`awk`**（BusyBox awk 即可）。

### 5.2 开启/关闭 trace：`echo 1` 与 `dscpstats` 的包含关系

trace 的开关就是**一个文件**：

```
/sys/kernel/debug/tracing/events/mac80211/wifi_dscp/enable   # 或 /sys/kernel/tracing/...
```

- `echo 1 > …/enable` 打开（埋点开始产生记录），`echo 0` 关闭。
- 用 `cat …/trace_pipe` 连续读取事件（**消费式**）；`cat …/trace` 是**不消费**的快照。
- 另有全局总闸 `tracing_on`（默认 1），**两者都为真**才会记录。

**关键：`dscpstats` 就是在这套手动操作外面包了一层，`echo 1` 只是它内部的一步。** 关系如下：

```
手动方式（看原始记录）                 dscpstats（看统计表）
──────────────────────                ───────────────────────────────────
echo 1 > enable    ┐                  start = 找 tracefs
cat trace_pipe     ┘  你手动          + mkfifo FIFO
                                       + cat trace_pipe > FIFO   ← 就是“手动方式”
                                       + awk < FIFO（聚合）
                                       + echo 1 > enable         ← 就是“echo 1”
                                      stop  = echo 0 > enable     ← 就是“echo 0”
                                       + kill cat（awk 收到 EOF）
                                       + awk 收尾、打印表
```

所以请这样理解：

- **记录来源只有一种**（`wifi_dscp` 事件）；`dscpstats` 不是另一种记录方式，而是
  「手动开启 + 聚合出表」的**自动化版本**。
- `dscpstats start` **包含** `echo 1 > enable`；`dscpstats stop` **包含** `echo 0 > enable`。
- 两者共用**同一个 `trace_pipe`**，**不能同时跑**（会互相抢事件）。

```sh
T=/sys/kernel/debug/tracing
echo 1 > $T/events/mac80211/wifi_dscp/enable   # 开
cat $T/trace_pipe                              # 看原始行
echo 0 > $T/events/mac80211/wifi_dscp/enable   # 关
# 或者一步到位：/root/dscpstats start | status | stop
```

### 5.3 部署脚本

```sh
scp dscpstats dscpstats.awk root@<router>:/root/
ssh root@<router> chmod +x /root/dscpstats
```

两个脚本放同一目录（脚本用 `dirname $0` 找 `dscpstats.awk`）。

### 5.4 命令详解

| 命令 | 作用 |
|---|---|
| `dscpstats start` | 找 tracefs → 清状态 → 起 `cat trace_pipe > FIFO` 与 `awk` 后台聚合 → `echo 1 > enable`。已在跑则报错退出。 |
| `dscpstats status` | 读 `/tmp/dscpstats.state` 打印表格（**不依赖 tracefs**，可单独用）。无数据则报错。 |
| `dscpstats stop` | `echo 0 > enable` → 结束 `cat`（awk 收 EOF 落盘）→ 打印最终表格。 |
| `dscpstats help` | 打印用法与**各列含义**（同 `-h`/`--help`/`usage`）。 |

> 注意 busybox 的 `PATH` 不含 `.`：若脚本放在 `/root/`，要用 `./dscpstats` 或 `/root/dscpstats`，
> 或 `ln -s /root/dscpstats /usr/bin/dscpstats`（软链时 `dscpstats.awk` 也要能被 `dirname $0` 找到，
> 最省事是两个文件一起放到 `/usr/bin/`）。

环境变量（一般不用改）：

| 变量 | 说明 |
|---|---|
| `DSCPSTATS_TRACEFS` | 指定 tracefs 路径（默认自动找 `/sys/kernel/tracing` 或 `/sys/kernel/debug/tracing`）；测试用。 |
| `DSCPSTATS_AWK` | 指定聚合器 awk 脚本路径（默认 `dirname $0/dscpstats.awk`）。 |

### 5.5 造带 DSCP 的流量

**路由器侧（TX 方向，用 nft 打标）：**

```sh
nft add table ip mangle
nft "add chain ip mangle output { type route hook output priority mangle; }"
nft "add rule ip mangle output ip daddr <client-ip> ip dscp set af41 counter"
ping -c 20 <client-ip>
# 用完清理：nft delete table ip mangle
```

**Windows 客户端（RX 方向）：** `ping -v 136` / socket `IP_TOS` 通常**不会真正打标**，用**策略 QoS**（需管理员）：

```powershell
New-NetQosPolicy -Name 'DSCPtest' -IPDstPort 9999 -DSCPAction 34 -PolicyStore ActiveStore
# 用完删除：Remove-NetQosPolicy -Name 'DSCPtest' -Confirm:$false
```

发送示例（绑定到 Wi‑Fi 网卡源 IP，避免走有线）：

```powershell
$c = New-Object System.Net.Sockets.UdpClient
$c.Client.Bind((New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Parse('<wifi-ip>'),0)))
$b = New-Object byte[] 200
1..100 | ForEach-Object { [void]$c.Send($b,$b.Length,'<router>',9999) }
$c.Close()
```

> 同网段同时有有线/无线时，Windows 默认走有线（metric 小），需绑定 Wi‑Fi 源 IP 或调高有线 metric。

**支持的 DSCP（只有这 8 个会产生事件，其余不统计、不占 trace 带宽）：**

| 事件值 | DSCP | 业务名 |
|---|---|---|
| `0x88` | AF41 | video-call-media |
| `0xa0` | CS5  | video-call-signal |
| `0x80` | CS4  | gaming |
| `0x68` | AF31 | video-streaming |
| `0x48` | AF21 | browsing |
| `0x30` | AF12 | file-upload |
| `0x28` | AF11 | email |
| `0x20` | CS1  | background |

### 5.6 输出解读

**报表列：**

```
DSCP  business   TXpkts TXbytes ACK fail  queue us avg/min/max  access us avg/min/max  e2e us avg/min/max  RXpkts RXbytes retryP reAvg reMax re%
0x88  video-call-media  ...                                            ...                 ...         2675   0.2     6 19.5
```

- `queue` = **ENQ→DEQ**（软件排队）；`access` = **DEQ→ACK**（信道接入，用户态按 `access = e2e - queue` 推导）；`e2e` = **ENQ→ACK**。
- 每个分量 `avg/min/max` 单位是 **us**；`min/max` 是**单包极值**（非分位数）。
- `ACK` = `acked=1` 的包数；`fail` = `acked=0` 的包数；`access`/`e2e` 只统计 acked 的包。
- `RXpkts/RXbytes` = 收方向的包/字节（只计数，不算时延）。
- **`retryP`** = 发生过重传（`retry>=1`）的 TX 帧数；**`reAvg`** = 平均重传次数/帧
  （重传总数 ÷ `(ACK+fail)`）；**`reMax`** = 单帧最大重传次数；**`re%`** = 重传率
  = `retryP ÷ (ACK+fail) × 100`（需要重传的帧占比）。
- 末尾 `window: N s` = 窗口时长。
- 输入 `dscpstats help` 会在设备上直接打印这一节（各列含义 + 口径）。

> **`Fail` 是什么**：ACK 事件里 `acked=0` 的包数，即**发送后未收到确认（ACK 失败）或发送中被丢弃**的包。
> 内核侧 `acked = info->flags & IEEE80211_TX_STAT_ACK`，若 `dropped` 则强制为 0（`status.c`）。
>
> **`retry` 是什么**：内核侧每帧的 MAC 层重传次数（`ieee80211_tx_get_rates()`），在 ACK 阶段写入事件。
> 本平台**必须**配合 mt76 驱动补丁 `355`（§3.7），否则恒为 0。

**状态文件（做看板/二次开发用）：**

- `/tmp/dscpstats.state`：每 DSCP 一行，**22 个**空格分隔字段（时间单位 **ns**）：
  ```
  dscp pkts bytes qcnt qsum qmin qmax ecnt esum emin emax acnt asum amin amax ack fail rpkts rbytes retp rets retm
  ```
  （末尾 3 个是 retry：`retp`=有重传的帧数、`rets`=重传总数、`retm`=单帧最大；报表的 `retryP/reAvg/reMax/re%` 由它算出。）
- `/tmp/dscpstats.start`：窗口起始 epoch 秒；运行中临时文件 `/tmp/dscpstats.{pid,catpid,fifo}`。
- 约每秒（或每 4096 事件）**原子写**（`mv` 替换）。`status` 读的就是它；任何进程读即最新快照。
- 需要 JSON/速率/历史/分位数则需另加子命令或 HTTP 端点（尚未实现）。

### 5.7 排查：看原始事件

```sh
T=/sys/kernel/debug/tracing
echo 1 > $T/events/mac80211/wifi_dscp/enable
cat $T/trace_pipe
echo 0 > $T/events/mac80211/wifi_dscp/enable
```

```
... wifi_dscp: dir=0 stage=0 dscp=0x88 len=242 skb=0000000083729f44 ts=... acked=0 retry=0
... wifi_dscp: dir=0 stage=2 dscp=0x00 len=242 skb=0000000083729f44 ts=... acked=1 retry=1
```

- `dir`：0=TX，1=RX；`stage`：0=ENQ，1=DEQ，2=ACK，3=RX。
- `skb` 在 trace 里被哈希，但同一 skb 一致，用于关联 TX 三阶段。
- `retry`：仅 ACK 阶段非 0（该帧重传次数）；ENQ/DEQ/RX 恒为 0。要看它非 0 需有驱动补丁 `355`。
- **别同时**手动 enable 和 `dscpstats start`（都读 `trace_pipe`，会抢事件）。

---

## 6. 已知限制与踩坑

### 6.1 RX 埋点为什么放两处（已解决的关键坑）

曾出现：客户端→路由器方向确认有 Wi‑Fi 收包、也有 TX ACK，但 **trace 里没有任何 `stage=3`（RX）事件**。
根因是 mt7996 的 RX data 帧走 **decap‑offload / fast‑rx** 路径（帧已是 802.3 形态），
**绕过** `ieee80211_rx_h_data()`，之前只看慢路径自然收不到。

**修复**：在 `ieee80211_rx_8023()` 增加 RX 埋点覆盖那两条路径，原 `ieee80211_rx_h_data()`
埋点保留作慢路径兜底；两者互斥，不会重复计数。已上机逐包验证通过。

### 6.2 其它

- **A‑MSDU / A‑MPDU**：本平台 tx/rx 头转换与 A‑MSDU 聚合都在固件里完成，
  mac80211 侧拿到的是 **MSDU**；RX A‑MSDU 由 mt76 预拆后逐个上交，实测逐包计数准确。
  换成软件加密/非 encap 驱动需重新评估。
- **ACK 依赖驱动逐帧回报**（`REQ_TX_STATUS`）；驱动不支持时 `acked` 恒 0（本平台支持）。
- **重传数依赖驱动上报**：mac80211 的 `retry_count` 来自 legacy `status.rates[]`，mt7996 不填，
  故需驱动补丁 `355`（§3.7）。不上驱动补丁时 `retry` 恒 0；且注意 `iw station dump` 的
  `tx retries` 会与 `tx failed` 同步增长（union 残留），**不要拿它当重传数**。
- **A‑MPDU 帧**：mac80211 对 `AMPDU && !STAT_AMPDU` 会强制 `retry=0`；本平台当前测试场景
  （2.4G legacy/WMM off）为逐包非聚合，retry 正常。聚合场景的重传口径需另行验证。
- **ACK 事件对所有 data 帧都会发**（payload 已加密、`dscp=0`，由用户态按 skb 回填），
  所以 trace 量 ≈ 发送的 data 帧数，不只是这 8 个 DSCP。
- **只支持 IPv4**；分片 / skb 复用可能产生少量无匹配条目，脚本自动跳过。
- **高包量**下 `trace_pipe` + awk 可能跟不上，可只保留部分阶段以降载。

### 6.3 常见问题（FAQ）

- **`status` 一直没数据**：确认先 `start`，且确实有 §5.5 里那 8 个 DSCP 的流量；
  DSCP 打标没生效（尤其 Windows `ping -v`）是最常见原因。
- **`start` 报 `missing`**：`wifi_dscp` 事件不存在 → 补丁未编入（见 §4）。
- **`start` 报 `tracefs not mounted`**：见 §5.1。
- **看不见 RX（`stage=3`）**：见 §6.1（曾因只埋了慢路径而收不到，已修复）。

---

## 7. 口径与实时读取

- **吞吐口径**：本平台 mac80211 侧 `skb` = **MSDU**，所以统计的是
  「每 DSCP 的 MSDU/IP goodput」（包数、字节数、速率），**不是** MPDU/PPDU 空口吞吐。
  空口 airtime 在 mac80211 拿不到（`ieee80211_rx_status` 无 airtime 字段），
  要 MPDU/空口口径必须改 mt76/固件侧。
- **重传口径**：`retry` 是 **MAC 层每帧的重传次数**（未收到 ACK 时的重发次数），来自 mac80211 的
  per-frame `retry_count`。`re%` 是「需要重传的帧占比」，`reAvg` 是「平均重传次数/帧」；
  失败帧（`fail`）也会计入分母。需 MT7996 驱动补丁（§3.7）。
- **实时读取**：`dscpstats.awk` 约每秒（或每 4096 事件）**原子写** `/tmp/dscpstats.state`
  （空格分隔，每 DSCP 一行，**22 字段**，时间单位 ns）；`/tmp/dscpstats.start` 是窗口起始 epoch。
  任何进程读该文件即最新快照，可做看板（`dscpstats status` 亦如此，且不依赖 tracefs）。
  需要 JSON/速率/历史/分位数则需另加子命令或 HTTP 端点（尚未实现）。

---

## 8. 附录

### 8.1 关于补丁

补丁的生成原理与完整步骤见 **§4.2**（改参考树 → 生成补丁 → 校验 → 放入）。要点：

- 权威来源：mac80211 是参考树 `backports-src/backports-6.12.96/`（改它再生成 `354`）；
  mt76 驱动是独立小补丁 `355`（对 mt76 包源码 diff）。
- 不要手改现有补丁；补丁里不要含调试 `printk`；`index` 行哈希每次会变。
- 生成后同步生效副本：
  - `cp .../354-*.patch openwrt/package/kernel/mac80211/patches/subsys/`
  - `cp .../355-*.patch openwrt/package/kernel/mt76/patches/`
- 验证：对 pristine 与「OpenWrt 全量补丁栈之后」均 `patch -p1 --dry-run` 干净通过；
  `grep -c '^@@' 354-*.patch` 应为 **16**。

### 8.2 部署决策与命令（换 `.ko` / 刷机）

**何时只换 `.ko`，何时全量刷机：**

| 改动内容 | 需要做什么 |
|---|---|
| 只改 `net/mac80211/*`（补丁 `354`） | 重编 `kmod-mac80211` → **换 `mac80211.ko` + 重启**（无需刷机） |
| 改 mt76 驱动 `mt7996/mac.c`（补丁 `355`） | 重编 `kmod-mt7996e` → **换 `mt7996e.ko` + 重启** |
| **两者都要（本项目的完整功能）** | 两个 ko 一起换 + 重启（重传率需 `355`，见 §3.7） |
| 改内核 config / 其它 kmod / DTS / target / 新增包 | **全量编译 + 刷机** |
| 只改用户态脚本（`dscpstats*`） | `scp` 覆盖即可，无需重启 |

> 换单个 `.ko` 的前提：**vermagic 一致**且没改到别模块依赖的 ABI。
> 本补丁只在 mac80211 内部加了 `static inline` 和一个 tracepoint，未改对外 ABI，所以只换 `mac80211.ko` 是安全的。
>
> **不要 `rmmod mac80211`/`mt7996e` 热重载**：mt7996 固件会崩，只能断电冷启动。所以永远是「换文件 + 重启」。

**换 `.ko`（§4.6 已给出流程，这里补充 ipk 方式）**：

```sh
# a) 直接换文件
scp .../mac80211.ko root@<router>:/tmp/mac80211.ko
ssh root@<router> 'K=$(uname -r); cp /lib/modules/$K/mac80211.ko /lib/modules/$K/mac80211.ko.bak; \
                   cp /tmp/mac80211.ko /lib/modules/$K/mac80211.ko; reboot'

# b) 用 ipk（保留 opkg 元数据，推荐）
scp .../kmod-mac80211_*.ipk root@<router>:/tmp/
ssh root@<router> 'opkg install --force-reinstall /tmp/kmod-mac80211_*.ipk; reboot'
```

**全量刷机（BPI‑R4，SD 启动）**：

```sh
# SD 卡直写
zcat openwrt-mediatek-filogic-bananapi_bpi-r4-sdcard.img.gz | sudo dd of=/dev/sdX bs=4M conv=fsync
# 系统在跑时用 sysupgrade（-n 不保留配置）
scp ...-squashfs-sysupgrade.itb root@<router>:/tmp/
ssh root@<router> sysupgrade -n /tmp/...-squashfs-sysupgrade.itb
```

### 8.3 纯软件自测（无需硬件）

```sh
sh test/run_tests.sh
```

- **L2**：用合成事件流喂 `dscpstats.awk`，比对 state 文件 golden、schema、报表渲染。
- **L3**：造假 tracefs（`DSCPSTATS_TRACEFS`），跑真 `start → 灌事件 → stop`，
  验证 enable 开关、FIFO/pid 生命周期、聚合结果、错误路径。

### 8.4 实测结果摘要

- **2.4G legacy（ch6）**：TX 全链路 ENQ→DEQ→ACK 通，例如 AF41（0x88）
  `queue 21.6us / access 2547us / e2e 2569us`（20 包，0 失败）。
- **5G Wi‑Fi 6（HE80, ch36, 1201Mbps, A‑MPDU 已启用）**：RX 逐包准确
  —— 发 100 个 AF41 UDP，trace 恰 100 条 `stage=3 dscp=0x88`；整段 260 包报表
  `RXpkts=260 RXbytes=62920`（=260×242）。结论：**Wi‑Fi 6 聚合下 RX 无漏计**。
- **TX 重传率（2.4G legacy，含驱动补丁 `355`）**：AF41 造流后
  ```
  DSCP business             TXpkts  retryP reAvg reMax  re%
  0x88 video-call-media      13688    2675   0.2     6  19.5
  ```
  即 **19.5% 的 TX 帧发生过重传**，平均 0.2 次/帧，单帧最多 6 次。ACK 事件的 `retry` 直方图为
  `0/1/2/3 = 5184/359/30/5`（成功帧也有 `retry≥1`，确为实际尝试次数）。
- **反例（重要）**：**只打 mac80211 补丁、不打驱动补丁**时，同一测试下所有 ACK 的 `retry` 恒为 0
  —— 因为 mt7996 不往 mac80211 上报 legacy `count`（§3.7）。所以重传率**必须**两个补丁一起上。
- 平台事实：mt7996 `hwflags` 含 `SUPPORTS_TX_ENCAP_OFFLOAD` /
  `SUPPORTS_RX_DECAP_OFFLOAD` / `SUPPORTS_AMSDU_IN_AMPDU`，故 mac80211 侧单位是 MSDU。

完整数据与固件版本见 `REQUIREMENTS.md` §11。

### 8.5 改动登记

> 本目录非 git 仓库，改动登记于此；明细见 `REQUIREMENTS.md`。

**本轮：新增 TX 重传率**

| 文件 | 改动 |
|---|---|
| `354-*.patch` | `wifi_dscp` 事件加 `u8 retry` 字段；`status.c` 的 ACK 埋点加 `int retry_count` 形参并从 3 个调用点传入、`tx_status_ext` 里初始化；顺带删掉参考树里多余的一行 `A`；重新生成（**16 hunk**） |
| `355-*.patch` | **新增**（mt76 驱动）：`mt7996_mac_add_txs_skb` 用 `MT_TXS5_F0_TX_COUNT` 填 `status.rates[0].count`，让 mac80211 算出真实重传数 |
| `backports-6.12.96/net/mac80211/{ieee80211_i.h,trace.h,tx,status,rx}.c` | 参考树与补丁同步（`retry` 字段 + 各调用点补 `0`） |
| `dscpstats` | 报表加 `retryP/reAvg/reMax/re%`；文件头加**指标说明**；新增 `help` 子命令 |
| `dscpstats.awk` | ACK 阶段聚合 retry（`retp/rets/retm`），state **19→22 列** |
| `test/{gen_events.sh,l2_aggregate.sh,expected/*}` | 带 retry 的 golden 用例 |
| `README.md` | 更新到含 retry + 驱动补丁（§1/§2/§3.2/§3.4/§3.7/§4/§5/§6/§7/§8） |

验证：两个补丁对 pristine 干净应用、`355` 与参考树回放一致；`sh test/run_tests.sh` L2/L3 全绿；
上机 `mac80211.ko`(`268b9224…`) + `mt7996e.ko`(`3d3df01c…`) 后 TX 重传率正确（§8.4）。

**前一轮：RX 埋点修复**

| 文件 | 改动 |
|---|---|
| `354-*.patch` | 新增 `rx.c` 的 `ieee80211_rx_8023()` RX 埋点，并重新生成补丁 |
| `backports-6.12.96/net/mac80211/{rx,status,tx}.c` | 与补丁同步 |
| `dscpstats.awk` | 落盘条件 `n%4096==0 && 跨秒` → `n%4096==0 \|\| 跨秒`（修复运行中 `status` 空表） |
| `README.md` | 合并 `USAGE.md` 为唯一总文档；§3 逐文件改动 + §3.6 DSCP 识别示意图；§4 端到端复现；§5 用户手册 |
| `USAGE.md` | 已并入 `README.md` §5，删除 |
