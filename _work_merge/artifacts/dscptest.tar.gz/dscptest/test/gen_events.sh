#!/bin/sh
#
# Emit synthetic mac80211:wifi_dscp trace lines in the kernel TP_printk
# format, so the userspace pipeline can be exercised without any hardware.
#
# Usage: gen_events.sh <scenario>
#
# The trace header is realistic (the awk program strips everything up to and
# including "wifi_dscp: "). Two skb notations are used on purpose: the hashed
# %p form (no "0x" prefix) and a literal "0x..." form; the parser must treat
# both as opaque strings.
#
# Stages: 0=ENQ 1=DEQ 2=ACK 3=RX. "retry" is only meaningful on the ACK stage
# (0 elsewhere); the ACK retry values below are chosen to cover the aggregation
# paths (0, single retry, several retries).

# ev <dir> <stage> <dscp> <len> <skb> <ts> <acked> <retry>
ev() {
	printf 'kworker/u8:2-123  [002] d.h. 100.000000: wifi_dscp: dir=%s stage=%s dscp=%s len=%s skb=%s ts=%s acked=%s retry=%s\n' \
		"$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8"
}

case "$1" in
normal)
	ev 0 0 0x88 1400 00000000deadbeef 1000 0 0
	ev 0 1 0x88 1400 00000000deadbeef 2000 0 0
	ev 0 2 0x00 1400 00000000deadbeef 5000 1 0
	;;
fail)
	# Failed after three retries.
	ev 0 0 0xa0 100 00000000deadbeef 1000 0 0
	ev 0 1 0xa0 100 00000000deadbeef 1500 0 0
	ev 0 2 0x00 100 00000000deadbeef 2000 0 3
	;;
orphan)
	# DEQ and ACK with no matching ENQ must be dropped entirely.
	ev 0 1 0x80 50 0xffff888012345678 100 0 0
	ev 0 2 0x00 50 0xffff888012345678 200 1 0
	;;
multi)
	ev 0 0 0x88 1400 00000000deadbeef 1000 0 0
	ev 0 0 0x48 200 0xffff888012345678 1000 0 0
	ev 0 1 0x88 1400 00000000deadbeef 2000 0 0
	ev 0 1 0x48 200 0xffff888012345678 3000 0 0
	ev 0 2 0x00 1400 00000000deadbeef 5000 1 0
	ev 0 2 0x00 200 0xffff888012345678 6000 1 2
	;;
rx)
	ev 1 3 0x20 500 0xffff888012345678 1000 0 0
	;;
reuse)
	# Same skb pointer reused after a completed packet, different DSCP.
	ev 0 0 0x88 100 00000000deadbeef 1000 0 0
	ev 0 1 0x88 100 00000000deadbeef 2000 0 0
	ev 0 2 0x00 100 00000000deadbeef 3000 1 0
	ev 0 0 0x48 100 00000000deadbeef 10000 0 0
	ev 0 1 0x48 100 00000000deadbeef 11000 0 0
	ev 0 2 0x00 100 00000000deadbeef 13000 1 1
	;;
mixed)
	# Used by the L3 pipeline test: one full TX packet + one RX packet.
	ev 0 0 0x88 1400 00000000deadbeef 1000 0 0
	ev 0 1 0x88 1400 00000000deadbeef 2000 0 0
	ev 0 2 0x00 1400 00000000deadbeef 5000 1 0
	ev 1 3 0x20 500 0xffff888012345678 3000 0 0
	;;
*)
	echo "usage: gen_events.sh <normal|fail|orphan|multi|rx|reuse|mixed>" >&2
	exit 1
	;;
esac
