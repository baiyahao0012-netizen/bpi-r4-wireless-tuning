#!/bin/sh
#
# dscpstats pure-software test runner (L2 + L3).
#
#   sh test/run_tests.sh
#
# L2: awk aggregator golden tests (synthetic trace lines).
# L3: dscpstats start/feed/stop pipeline against a fake tracefs.
# Offline, no root, no hardware required.

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

echo "==== L2: awk aggregator ===="
sh "$HERE/l2_aggregate.sh"
r2=$?

echo
echo "==== L3: shell pipeline ===="
sh "$HERE/l3_pipeline.sh"
r3=$?

echo
echo "==== summary ===="
[ "$r2" -eq 0 ] && echo "L2 PASS" || echo "L2 FAIL"
[ "$r3" -eq 0 ] && echo "L3 PASS" || echo "L3 FAIL"

[ "$r2" -eq 0 ] && [ "$r3" -eq 0 ]
