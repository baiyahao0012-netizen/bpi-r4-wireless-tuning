#!/bin/sh
#
# L3: dscpstats shell pipeline end-to-end simulation.
#
# Builds a fake tracefs tree under /tmp (events/mac80211/wifi_dscp/enable plus
# a trace_pipe FIFO) and points dscpstats at it through DSCPSTATS_TRACEFS, then
# runs the real start / feed / stop flow. Exercises the FIFO + background
# cat/awk plumbing, the enable switch, the state file and the report.

set -u

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DSCPSTATS="$HERE/../dscpstats"
GEN="$HERE/gen_events.sh"

TMP=$(mktemp -d /tmp/dscpstats-l3.XXXXXX) || exit 1
FAKE="$TMP/tracefs"
EV="$FAKE/events/mac80211/wifi_dscp"
mkdir -p "$EV"
: > "$EV/enable"
mkfifo "$FAKE/trace_pipe"
export DSCPSTATS_TRACEFS="$FAKE"

cleanup() {
	for f in /tmp/dscpstats.pid /tmp/dscpstats.catpid; do
		[ -f "$f" ] && kill "$(cat "$f")" 2>/dev/null
	done
	rm -f /tmp/dscpstats.state /tmp/dscpstats.pid /tmp/dscpstats.catpid \
	      /tmp/dscpstats.start /tmp/dscpstats.fifo
	rm -rf "$TMP"
}
trap cleanup EXIT INT TERM

reset() {
	rm -f /tmp/dscpstats.state /tmp/dscpstats.pid /tmp/dscpstats.catpid \
	      /tmp/dscpstats.start /tmp/dscpstats.fifo
	: > "$EV/enable"
}

pass=0
fail=0
rc=0
ok()  { echo "  PASS: $1"; pass=$((pass + 1)); }
bad() { echo "  FAIL: $1"; fail=$((fail + 1)); rc=1; }

wait_state() {
	i=0
	while [ ! -s /tmp/dscpstats.state ] && [ "$i" -lt 50 ]; do
		sleep 0.1
		i=$((i + 1))
	done
	sleep 0.3
}

echo "-- happy path (start -> feed -> stop) --"
reset
"$DSCPSTATS" start >/dev/null 2>&1 || bad "start failed"
[ "$(cat "$EV/enable" 2>/dev/null)" = "1" ] && ok "enable=1 after start" || bad "enable after start"
[ -f /tmp/dscpstats.pid ] && ok "pid file created" || bad "pid file"
[ -p /tmp/dscpstats.fifo ] && ok "fifo created" || bad "fifo"

"$GEN" mixed > "$FAKE/trace_pipe"
wait_state

got=$(sort /tmp/dscpstats.state 2>/dev/null)
want=$(sort "$HERE/expected/mixed")
if [ "$got" = "$want" ]; then
	ok "pipeline state matches golden"
else
	bad "pipeline state mismatch"
	echo "    got : $(echo "$got" | tr '\n' '|')"
	echo "    want: $(echo "$want" | tr '\n' '|')"
fi

out=$("$DSCPSTATS" stop 2>/dev/null)
[ "$(cat "$EV/enable" 2>/dev/null)" = "0" ] && ok "enable=0 after stop" || bad "enable after stop"
echo "$out" | grep -q "video-call-media" && ok "report has video-call-media" || bad "report video-call-media"
echo "$out" | grep -q "background" && ok "report has background" || bad "report background"
echo "$out" | grep -q "window:" && ok "report window" || bad "report window"
[ ! -f /tmp/dscpstats.pid ] && ok "pid file cleaned" || bad "pid file cleanup"
[ ! -f /tmp/dscpstats.catpid ] && ok "catpid file cleaned" || bad "catpid cleanup"
[ ! -e /tmp/dscpstats.fifo ] && ok "fifo cleaned" || bad "fifo cleanup"

echo "-- start twice --"
reset
"$DSCPSTATS" start >/dev/null 2>&1
"$DSCPSTATS" start >/dev/null 2>&1 && bad "second start must fail" || ok "second start rejected"
"$DSCPSTATS" stop >/dev/null 2>&1

echo "-- missing trace event --"
mkdir -p "$TMP/fake2/events"
DSCPSTATS_TRACEFS="$TMP/fake2" "$DSCPSTATS" start >/dev/null 2>&1 \
	&& bad "start without event must fail" || ok "start without event rejected"

echo "-- status with no data --"
rm -f /tmp/dscpstats.state
"$DSCPSTATS" status >/dev/null 2>&1 && bad "status no data must fail" || ok "status no data rejected"

echo "-- stop when not running --"
rm -f /tmp/dscpstats.pid
"$DSCPSTATS" stop >/dev/null 2>&1 && bad "stop idle must fail" || ok "stop idle rejected"

echo "L3: $pass passed, $fail failed"
exit $rc
