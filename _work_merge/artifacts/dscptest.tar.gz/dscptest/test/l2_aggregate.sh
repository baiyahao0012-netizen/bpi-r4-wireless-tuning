#!/bin/sh
#
# L2: awk aggregator golden tests.
#
# Feeds synthetic wifi_dscp event streams into dscpstats.awk and compares the
# resulting /tmp state file against expected/*. Also checks the state schema
# and the dscpstats status report rendering. No hardware, no tracefs needed.

set -u

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DSCPSTATS="$HERE/../dscpstats"
AWKPROG="$HERE/../dscpstats.awk"
GEN="$HERE/gen_events.sh"
EXP="$HERE/expected"

TMP=$(mktemp -d /tmp/dscpstats-l2.XXXXXX) || exit 1
trap 'rm -rf "$TMP"; rm -f /tmp/dscpstats.state /tmp/dscpstats.start' EXIT INT TERM

pass=0
fail=0
rc=0
ok()  { echo "  PASS: $1"; pass=$((pass + 1)); }
bad() { echo "  FAIL: $1"; fail=$((fail + 1)); rc=1; }

aggregate() { # <scenario> -> sorted state on stdout
	"$GEN" "$1" | awk -v out="$TMP/$1.state" -f "$AWKPROG"
	sort "$TMP/$1.state"
}

echo "-- syntax sanity --"
sh -n "$DSCPSTATS" && ok "dscpstats sh -n" || bad "dscpstats sh -n"
awk -f "$AWKPROG" </dev/null >/dev/null 2>&1 && ok "dscpstats.awk parses" || bad "dscpstats.awk parses"

echo "-- aggregate golden --"
for s in normal fail orphan multi rx reuse; do
	got=$(aggregate "$s")
	want=$(sort "$EXP/$s")
	if [ "$got" = "$want" ]; then
		ok "aggregate $s"
	else
		bad "aggregate $s"
		echo "    got : $(echo "$got" | tr '\n' '|')"
		echo "    want: $(echo "$want" | tr '\n' '|')"
	fi
done

echo "-- schema --"
n=$(awk '{print NF}' "$TMP/normal.state" | sort -u | tr -d ' ')
if [ "$n" = "22" ]; then
	ok "state has 22 fields per row"
else
	bad "state field count = '$n' (want 22)"
fi

echo "-- retry aggregation --"
# fail: one failed frame retried 3 times -> retp=1 rets=3 retm=3
got=$(awk '{print $NF, $(NF-1), $(NF-2)}' "$TMP/fail.state")
[ "$got" = "3 3 1" ] && ok "fail retry sum/max/count = 3/3/1" || bad "fail retry aggregation ($got)"
# multi: 0x48 acked after 2 retries -> retp=1 rets=2 retm=2
got=$(awk '$1=="0x48"{print $(NF-2), $(NF-1), $NF}' "$TMP/multi.state")
[ "$got" = "1 2 2" ] && ok "multi 0x48 retry count/sum/max = 1/2/2" || bad "multi retry aggregation ($got)"

echo "-- status report --"
printf '0x88 1 1400 1 1000 1000 1000 1 4000 4000 4000 1 3000 3000 3000 1 0 0 0 1 2000 4\n' \
	> /tmp/dscpstats.state
date +%s > /tmp/dscpstats.start
rep=$("$DSCPSTATS" status 2>/dev/null)
echo "$rep" | grep -q "video-call-media" && ok "report business name" || bad "report business name"
echo "$rep" | grep -q "window:" && ok "report window line" || bad "report window line"
echo "$rep" | grep -q "1.0/" && ok "report queue avg 1.0us" || bad "report queue avg"
echo "$rep" | grep -q "3.0/" && ok "report access avg 3.0us" || bad "report access avg"
echo "$rep" | grep -q "4.0/" && ok "report e2e avg 4.0us" || bad "report e2e avg"
echo "$rep" | grep -q "retryP" && ok "report retry column present" || bad "report retry column"
echo "$rep" | grep -q "2000.0" && ok "report retry avg 2000.0" || bad "report retry avg"
echo "$rep" | grep -q "100.0" && ok "report retry rate 100.0%" || bad "report retry rate"

echo "-- error path --"
rm -f /tmp/dscpstats.state
"$DSCPSTATS" status >/dev/null 2>&1 && bad "status with no data must fail" || ok "status with no data fails"

echo "L2: $pass passed, $fail failed"
exit $rc
