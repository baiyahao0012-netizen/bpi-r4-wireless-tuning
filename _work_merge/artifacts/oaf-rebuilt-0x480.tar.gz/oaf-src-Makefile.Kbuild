oaf-objs := fwx_main.o fwx_utils.o  regexp.o k_json.o  fwx_log.o fwx_client.o fwx_client_fs.o 
oaf-objs += fwx_conntrack.o  fwx_mac.o fwx_config.o fwx_mac_filter.o 
oaf-objs += fwx_app_filter.o
obj-m += oaf.o
