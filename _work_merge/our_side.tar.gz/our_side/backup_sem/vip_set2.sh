#!/bin/sh
# usage: vip_set2.sh <vip_ip> [dscp]
VIP="$1"
DSCP="${2:-ef}"
nft delete table ip vip 2>/dev/null
nft add table ip vip
nft add chain ip vip out '{ type route hook output priority mangle; }'
nft add rule ip vip out ip daddr "$VIP" counter ip dscp set "$DSCP"
nft list table ip vip
