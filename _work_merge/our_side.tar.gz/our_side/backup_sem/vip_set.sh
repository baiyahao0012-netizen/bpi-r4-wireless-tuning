#!/bin/sh
# usage: vip_set.sh <vip_ip> [normal_ip]
VIP="$1"
nft delete table ip vip 2>/dev/null
nft add table ip vip
nft add chain ip vip out '{ type route hook output priority mangle; }'
nft add rule ip vip out ip daddr "$VIP" counter ip dscp set ef
nft list table ip vip
