/*
 * wifi-rtc-l2.cc
 *
 * Mode B —— 无 IP 栈、无 UDP/TCP 的 SparkRTC over Wi-Fi。
 *
 * 拓扑：  STA(发送端)  <-->  AP  <-->  STA(接收端)
 *
 * 本脚本专用于 L2 直通设计，全程不接触 IPv4/UDP：
 *
 *   1. 不安装 InternetStackHelper，因此不存在 IP 地址，也没有 ARP、
 *      路由表和 UDP 头。
 *   2. 应用打开裸 PacketSocket（ns3::PacketSocket），直接写入位于
 *      802.11 MAC 之上的负载。
 *   3. 双方用 Mac48Address 而非 Ipv4Address 识别对端。
 *   4. RTC 帧用自定义 EtherType（0x88B5）加上 sparkrtc 的 RTC 头打标签，
 *      接收端据此解复用。
 *
 * 关于“无 IP”的措辞说明：RTC 头封装在 802.11 MAC 服务数据单元中。
 * 承载 EtherType 的 LLC/SNAP 属于链路层而非网络层，因此保留；
 * 被去除的是 IPv4 + UDP。
 *
 * 产物写入 scratch/rtc-test/，文件名带 "l2-" 前缀，与 mode A 和
 * 可切换脚本共享同一目录。
 *
 * 用法：
 *   ./ns3 run "wifi-rtc-l2 --simTime=30 --fecPolicy=webrtc --ccAlgo=none --bitrate=10000000"
 */

#include "rtc-wifi-common.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("WifiRtcModeB");

int
main(int argc, char* argv[])
{
    LogComponentEnable("WifiRtcModeB", LOG_LEVEL_INFO);

    rtcwifi::Config cfg;
    // Mode B 原样继承共享 Config 的所有默认值，因此它运行的参数集与
    // mode A、mode AB 完全相同。唯一被考察的差异是裸 802.11 帧中
    // 不携带 IP/UDP 头。

    CommandLine cmd(__FILE__);
    rtcwifi::AddOptions(cmd, cfg);
    cmd.Parse(argc, argv);

    rtcwifi::Run(cfg, TRANSPORT_L2, "Mode B");

    return 0;
}
