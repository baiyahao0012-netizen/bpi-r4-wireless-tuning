/*
 * rtc-e2e-stats.h
 *
 * SparkRTC Wi-Fi scratch 脚本共享的统计辅助头文件。
 *
 * sparkrtc 的应用日志（由 ns3::VideoDecoder 写入）每解码一帧输出一行：
 *
 *   Frame <id> encoded <encode_ms> played at <play_ms> missddl? <0|1>
 *
 * 本头文件把这些行转换成演示脚本打印的端到端汇总。它刻意不依赖具体的
 * 传输方式（UDP/IP 或 L2 直通），因此两种变体可以用同一套指标定义对比。
 */

#ifndef RTC_E2E_STATS_H
#define RTC_E2E_STATS_H

#include <cstdint>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace rtcstats
{

/**
 * \brief 从应用日志中收集的端到端播放统计。
 */
struct Summary
{
    uint64_t playedFrames{0};   //!< 完整接收并“播放”的帧数
    uint64_t onTimeFrames{0};   //!< 端到端时延在截止时间内的帧数
    uint64_t lateFrames{0};     //!< 超过播放截止时间才到达的帧数
    double meanDelayMs{0.0};    //!< 平均 (播放 - 编码) 时延，单位毫秒
};

/**
 * \brief 解析 sparkrtc 应用日志。
 *
 * 不符合预期格式的行会被忽略，这样即使日志格式演化，本辅助函数仍可使用。
 *
 * \param path 视频解码器写出的日志文件路径
 * \return 汇总结果；文件无法读取时全为 0
 */
inline Summary
ParseAppLog(const std::string& path)
{
    Summary summary;
    std::ifstream input(path);
    if (!input.is_open())
    {
        return summary;
    }

    double delaySumMs = 0.0;
    std::string line;
    while (std::getline(input, line))
    {
        std::istringstream stream(line);
        std::string token;
        uint64_t frameId = 0;
        int64_t encodeMs = 0;
        int64_t playMs = 0;
        int missDeadline = 0;

        // 字面量 "Frame"（必须与日志原文完全一致）
        if (!(stream >> token) || token != "Frame")
        {
            continue;
        }
        if (!(stream >> frameId))
        {
            continue;
        }
        // 字面量 "encoded"
        if (!(stream >> token) || token != "encoded")
        {
            continue;
        }
        if (!(stream >> encodeMs))
        {
            continue;
        }
        // 字面量 "played"
        if (!(stream >> token) || token != "played")
        {
            continue;
        }
        // 字面量 "at"
        if (!(stream >> token) || token != "at")
        {
            continue;
        }
        if (!(stream >> playMs))
        {
            continue;
        }
        // "missddl?"（由 ns3::VideoDecoder 写出）
        if (!(stream >> token))
        {
            continue;
        }
        if (!(stream >> missDeadline))
        {
            continue;
        }

        summary.playedFrames++;
        if (missDeadline != 0)
        {
            summary.lateFrames++;
        }
        else
        {
            summary.onTimeFrames++;
        }
        delaySumMs += static_cast<double>(playMs - encodeMs);
    }

    if (summary.playedFrames > 0)
    {
        summary.meanDelayMs = delaySumMs / static_cast<double>(summary.playedFrames);
    }
    return summary;
}

/**
 * \brief 准时率，单位为百分比。
 *
 * \param summary ParseAppLog() 返回的统计结果
 * \return 满足播放截止时间的帧占比；无帧播放时返回 0
 */
inline double
AccuracyPercent(const Summary& summary)
{
    return (summary.playedFrames > 0)
               ? (100.0 * static_cast<double>(summary.onTimeFrames) /
                  static_cast<double>(summary.playedFrames))
               : 0.0;
}

/**
 * \brief 按演示脚本使用的格式打印端到端汇总。
 *
 * \param summary ParseAppLog() 返回的统计结果
 * \param transport "udp" 或 "l2"
 * \param logPath 被解析的应用日志路径
 */
inline void
PrintAppLogSummary(const Summary& summary, const std::string& transport, const std::string& logPath)
{
    std::cout << "App E2E Summary (" << transport << "):\n";
    std::cout << "  Played Frames: " << summary.playedFrames << "\n";
    std::cout << "  On-time Frames: " << summary.onTimeFrames << "\n";
    std::cout << "  Late Frames: " << summary.lateFrames << "\n";
    std::cout << "  Accuracy (on-time ratio): " << AccuracyPercent(summary) << " %\n";
    std::cout << "  Mean E2E Delay: " << summary.meanDelayMs << " ms\n";
    std::cout << "  App Log: " << logPath << "\n";
}

/**
 * \brief 把本次运行的汇总追加写入共享文本文件。
 *
 * 所有脚本都写入同一目录，以追加方式保存可以让 mode A、mode B 和
 * 可切换模式的结果并排展示，便于直接比较。
 *
 * \param path 汇总文件路径
 * \param title 本次运行的短标签，例如 "Mode A"
 * \param transport "udp" 或 "l2"
 * \param logPath 被解析的应用日志路径
 * \param summary ParseAppLog() 返回的统计结果
 */
inline void
AppendSummaryFile(const std::string& path,
                  const std::string& title,
                  const std::string& transport,
                  const std::string& logPath,
                  const Summary& summary)
{
    std::ofstream out(path, std::ios::app);
    if (!out.is_open())
    {
        return;
    }

    /* 记录真实时钟时间戳，使同一模式的多次运行仍可区分。 */
    std::time_t now = std::time(nullptr);
    char stamp[32] = {0};
    std::strftime(stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S", std::localtime(&now));

    out << "===== " << title << " (" << transport << ") @ " << stamp << " =====\n";
    out << "PlayedFrames: " << summary.playedFrames << "\n";
    out << "OnTimeFrames: " << summary.onTimeFrames << "\n";
    out << "LateFrames: " << summary.lateFrames << "\n";
    out << "AccuracyPercent: " << AccuracyPercent(summary) << "\n";
    out << "MeanE2EDelayMs: " << summary.meanDelayMs << "\n";
    out << "AppLog: " << logPath << "\n\n";
}

} // namespace rtcstats

#endif /* RTC_E2E_STATS_H */
