/*
 * rtc-wifi-common.h
 *
 * SparkRTC over Wi-Fi 系列 scratch 脚本的公共拓扑与运行器。
 *
 * 三个脚本都基于本头文件，区别仅在传输方式：
 *
 *   wifi-rtc-demo.cc    Mode A  - 完整协议栈（IPv4 + UDP），参照基线
 *   wifi-rtc-l2.cc      Mode B  - 无 IP 栈，在 802.11 MAC 之上直接使用裸 PacketSocket
 *   wifi-rtc-switch.cc  Mode AB - 两者合一，通过 --transport=udp|l2 选择
 *
 * 把拓扑、时序、FEC 和日志集中在一处，可保证 A / B 两种模式的对比中，
 * 传输方式是唯一的变量。
 *
 * 所有运行产物写入同一个目录（默认 scratch/rtc-test），文件名带传输方式前缀，
 * 因此多次运行的结果可以并排比较。
 */

#ifndef RTC_WIFI_COMMON_H
#define RTC_WIFI_COMMON_H

#include "rtc-e2e-stats.h"

#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/sparkrtc-module.h"
#include "ns3/wifi-module.h"
#include "ns3/yans-wifi-channel.h"

#include <cstdint>
#include <filesystem>
#include <sstream>
#include <string>

using namespace ns3;

namespace rtcwifi
{

/*
 * 下面这些 inline 函数中用到的 NS_LOG 宏会在头文件内部展开，因此需要一个
 * 在本头文件中就已完成声明的日志组件，不能依赖包含它的 .cc 文件里声明的那个。
 */
NS_LOG_COMPONENT_DEFINE("RtcWifiCommon");

/**
 * \brief 三个 RTC-over-Wi-Fi 脚本共享的参数。
 *
 * 三个脚本（mode A、mode B 和可切换的 mode AB）都原样继承这些默认值，
 * 因此无论用哪个可执行文件，不加参数运行的实验完全相同。
 * 这里的取值对应参照对照配置：WebRTC FEC、不使用拥塞控制、10 Mbps、30 秒。
 */
struct Config
{
    std::string fecPolicyName{"webrtc"}; //!< hairpin / webrtc / none
    std::string ccAlgo{"none"};          //!< gcc / nada / none
    uint32_t bitrateBps{10000000};       //!< 目标视频码率（10 Mbps）
    double simTime{30.0};                //!< 仿真时长（秒）

    std::string wifiStandard{"11ax"}; //!< 11ax / 11ac / 11n
    uint32_t channelWidth{80};        //!< 信道带宽（MHz）

    uint16_t appPort{8000};        //!< UDP 端口（仅 mode A 使用）
    uint16_t fps{60};              //!< 视频帧率
    uint16_t delayDdlMs{100};      //!< 播放截止时间
    uint16_t intervalMs{16};       //!< 编码器发送间隔
    uint32_t receiverWindowMs{34}; //!< 接收端统计窗口

    std::string outputDir{"scratch/rtc-test"}; //!< 唯一共享的输出目录
};

/**
 * \brief 某一传输方式对应的产物路径。
 */
struct Paths
{
    std::string dir;      //!< 共享输出目录
    std::string fec;      //!< FEC 跟踪日志
    std::string app;      //!< 逐帧应用日志
    std::string debug;    //!< 调试跟踪
    std::string phyTrace; //!< Wi-Fi 物理层 ASCII 跟踪
    std::string summary;  //!< 追加式运行汇总
};

/**
 * \brief 注册所有公共命令行参数。
 *
 * 可切换脚本会在此基础上额外添加 --transport。
 */
inline void
AddOptions(CommandLine& cmd, Config& cfg)
{
    cmd.AddValue("fecPolicy", "FEC policy (hairpin/webrtc/none)", cfg.fecPolicyName);
    cmd.AddValue("ccAlgo", "Congestion control (gcc/nada/none)", cfg.ccAlgo);
    cmd.AddValue("bitrate", "Target video bitrate (bps)", cfg.bitrateBps);
    cmd.AddValue("simTime", "Simulation duration in seconds", cfg.simTime);
    cmd.AddValue("wifiStandard", "Wi-Fi standard (11ax/11ac/11n)", cfg.wifiStandard);
    cmd.AddValue("channelWidth", "Channel width in MHz", cfg.channelWidth);
    cmd.AddValue("outputDir", "Directory for log/tr outputs", cfg.outputDir);
}

/**
 * \brief 用作文件名前缀的传输方式短标签。
 */
inline std::string
Tag(TransportMode mode)
{
    return (mode == TRANSPORT_L2) ? "l2" : "udp";
}

/**
 * \brief 在共享目录下构造某一传输方式的所有产物路径。
 */
inline Paths
MakePaths(const std::string& dir, TransportMode mode)
{
    const std::string tag = Tag(mode);
    Paths paths;
    paths.dir = dir;
    paths.fec = dir + "/" + tag + "-fec.log";
    paths.app = dir + "/" + tag + "-app.log";
    paths.debug = dir + "/" + tag + "-debug.log";
    paths.phyTrace = dir + "/" + tag + "-phy.tr";
    paths.summary = dir + "/summary.txt";
    return paths;
}

/**
 * \brief 按命令行参数创建对应的 FEC 策略对象。
 */
inline Ptr<FECPolicy>
CreateFecPolicy(const std::string& name, uint16_t delayDdlMs)
{
    if (name == "hairpin")
    {
        return CreateObject<HairpinPolicy>(delayDdlMs, 1e-7, true, false);
    }
    if (name == "webrtc")
    {
        return CreateObject<WebRTCPolicy>();
    }
    if (name == "none")
    {
        return CreateObject<FixedPolicy>(0.0);
    }

    NS_LOG_WARN("Unsupported fecPolicy='" << name << "', fallback to none");
    return CreateObject<FixedPolicy>(0.0);
}

/**
 * \brief 返回节点上第一个 WifiNetDevice 的索引。
 *
 * L2 路径需要显式指定设备索引，以便 PacketSocket 只使用 Wi-Fi 网卡。
 */
inline uint32_t
GetWifiDeviceIndex(Ptr<Node> node)
{
    for (uint32_t i = 0; i < node->GetNDevices(); i++)
    {
        if (DynamicCast<WifiNetDevice>(node->GetDevice(i)))
        {
            return i;
        }
    }
    NS_ABORT_MSG("No WifiNetDevice found on node " << node->GetId());
    return 0;
}

/**
 * \brief 返回节点 Wi-Fi 网卡的 MAC 地址。
 */
inline Mac48Address
GetWifiMacAddress(Ptr<Node> node, uint32_t deviceIndex)
{
    return Mac48Address::ConvertFrom(node->GetDevice(deviceIndex)->GetAddress());
}

/**
 * \brief 构建 STA/AP 拓扑、运行仿真并输出结果。
 *
 * \param cfg 仿真参数
 * \param mode 使用的传输方式
 * \param title 写入共享汇总文件的标签，例如 "Mode A"
 * \return 从应用日志解析出的端到端播放统计
 */
inline rtcstats::Summary
Run(const Config& cfg, TransportMode mode, const std::string& title)
{
    const bool useL2 = (mode == TRANSPORT_L2);
    const std::string transport = Tag(mode);

    const Paths paths = MakePaths(cfg.outputDir, mode);
    std::error_code ec;
    std::filesystem::create_directories(paths.dir, ec);
    if (ec)
    {
        NS_ABORT_MSG("Failed to create outputDir='" << paths.dir << "': " << ec.message());
    }

    /* ---------- 拓扑：STA(发送端) <-> AP <-> STA(接收端) ---------- */
    NodeContainer wifiStaNodes;
    wifiStaNodes.Create(2);
    NodeContainer wifiApNode;
    wifiApNode.Create(1);

    uint32_t channelWidth = cfg.channelWidth;

    WifiHelper wifi;
    if (cfg.wifiStandard == "11ax")
    {
        wifi.SetStandard(WIFI_STANDARD_80211ax);
    }
    else if (cfg.wifiStandard == "11ac")
    {
        wifi.SetStandard(WIFI_STANDARD_80211ac);
    }
    else
    {
        wifi.SetStandard(WIFI_STANDARD_80211n);
        if (channelWidth > 40)
        {
            NS_LOG_WARN("11n typically supports <=40MHz; clamp channelWidth to 40");
            channelWidth = 40;
        }
    }

    YansWifiChannelHelper channelHelper;
    channelHelper.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channelHelper.AddPropagationLoss("ns3::LogDistancePropagationLossModel",
                                     "Exponent",
                                     DoubleValue(3.0),
                                     "ReferenceLoss",
                                     DoubleValue(40.0));

    YansWifiPhyHelper phy;
    phy.SetChannel(channelHelper.Create());

    const std::string band = (cfg.wifiStandard == "11n") ? "BAND_2_4GHZ" : "BAND_5GHZ";
    std::ostringstream channelSettings;
    channelSettings << "{0, " << channelWidth << ", " << band << ", 0}";
    phy.Set("ChannelSettings", StringValue(channelSettings.str()));

    WifiMacHelper mac;
    Ssid ssid = Ssid("SparkRtcSsid");

    mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid));
    NetDeviceContainer staDevices = wifi.Install(phy, mac, wifiStaNodes);

    mac.SetType("ns3::ApWifiMac",
                "Ssid",
                SsidValue(ssid),
                "EnableBeaconJitter",
                BooleanValue(false));
    NetDeviceContainer apDevices = wifi.Install(phy, mac, wifiApNode);

    MobilityHelper mobility;
    Ptr<ListPositionAllocator> staAlloc = CreateObject<ListPositionAllocator>();
    staAlloc->Add(Vector(-10.0, 0.0, 0.0));
    staAlloc->Add(Vector(10.0, 0.0, 0.0));
    mobility.SetPositionAllocator(staAlloc);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(wifiStaNodes);

    Ptr<ListPositionAllocator> apAlloc = CreateObject<ListPositionAllocator>();
    apAlloc->Add(Vector(0.0, 0.0, 0.0));
    mobility.SetPositionAllocator(apAlloc);
    mobility.Install(wifiApNode);

    /* ---------- 协议栈：这是两种模式之间唯一的差异之处 ---------- */
    Ipv4InterfaceContainer staInterfaces;

    if (!useL2)
    {
        InternetStackHelper internet;
        internet.Install(wifiStaNodes);
        internet.Install(wifiApNode);

        Ipv4AddressHelper ipv4;
        ipv4.SetBase("192.168.1.0", "255.255.255.0");
        staInterfaces = ipv4.Assign(staDevices);
        ipv4.Assign(apDevices);

        Ipv4GlobalRoutingHelper::PopulateRoutingTables();
    }
    else
    {
        /*
         * PacketSocket 要求每个打开裸 socket 的节点上都存在 PacketSocketFactory。
         * PacketSocketHelper 只负责聚合该工厂，不安装任何协议层。
         */
        PacketSocketHelper packetSocket;
        packetSocket.Install(wifiStaNodes);
        packetSocket.Install(wifiApNode);
    }

    const uint32_t senderDeviceIndex = GetWifiDeviceIndex(wifiStaNodes.Get(0));
    const uint32_t receiverDeviceIndex = GetWifiDeviceIndex(wifiStaNodes.Get(1));
    const Mac48Address senderMac = GetWifiMacAddress(wifiStaNodes.Get(0), senderDeviceIndex);
    const Mac48Address receiverMac = GetWifiMacAddress(wifiStaNodes.Get(1), receiverDeviceIndex);

    /* ---------- 应用层 ---------- */
    AsciiTraceHelper ascii;
    Ptr<OutputStreamWrapper> fecStream = ascii.CreateFileStream(paths.fec);
    Ptr<OutputStreamWrapper> appStream = ascii.CreateFileStream(paths.app);
    Ptr<OutputStreamWrapper> debugStream = ascii.CreateFileStream(paths.debug);

    Ptr<FECPolicy> fecPolicy = CreateFecPolicy(cfg.fecPolicyName, cfg.delayDdlMs);

    Ipv4Address senderIp;
    Ipv4Address receiverIp;

    Ptr<GameServer> senderApp = CreateObject<GameServer>();
    Ptr<GameClient> receiverApp = CreateObject<GameClient>();
    wifiStaNodes.Get(0)->AddApplication(senderApp);
    wifiStaNodes.Get(1)->AddApplication(receiverApp);

    if (useL2)
    {
        senderApp->SetupL2(senderMac,
                           receiverMac,
                           RTC_L2_ETHERTYPE,
                           senderDeviceIndex,
                           cfg.fps,
                           MilliSeconds(cfg.delayDdlMs),
                           cfg.bitrateBps / 1000,
                           cfg.intervalMs,
                           fecPolicy,
                           "dupack",
                           MilliSeconds(cfg.receiverWindowMs),
                           20,
                           static_cast<double>(cfg.bitrateBps) / 1e6,
                           0.0,
                           0.01,
                           false,
                           "",
                           fecStream,
                           debugStream);

        receiverApp->SetupL2(receiverMac,
                             senderMac,
                             RTC_L2_ETHERTYPE,
                             receiverDeviceIndex,
                             cfg.fps,
                             MicroSeconds(cfg.delayDdlMs * 1000),
                             cfg.receiverWindowMs * 1000,
                             20,
                             appStream,
                             debugStream);
    }
    else
    {
        senderIp = staInterfaces.GetAddress(0);
        receiverIp = staInterfaces.GetAddress(1);

        senderApp->Setup(senderIp,
                         cfg.appPort,
                         receiverIp,
                         cfg.appPort,
                         cfg.fps,
                         MilliSeconds(cfg.delayDdlMs),
                         cfg.bitrateBps / 1000,
                         cfg.intervalMs,
                         fecPolicy,
                         "dupack",
                         MilliSeconds(cfg.receiverWindowMs),
                         20,
                         static_cast<double>(cfg.bitrateBps) / 1e6,
                         0.0,
                         0.01,
                         false,
                         "",
                         fecStream,
                         debugStream);

        receiverApp->Setup(senderIp,
                           cfg.appPort,
                           cfg.appPort,
                           cfg.fps,
                           MicroSeconds(cfg.delayDdlMs * 1000),
                           cfg.receiverWindowMs * 1000,
                           20,
                           appStream,
                           debugStream);
    }

    if (cfg.ccAlgo == "gcc")
    {
        senderApp->SetController(GCC);
    }
    else if (cfg.ccAlgo == "nada")
    {
        senderApp->SetController(NADA);
    }

    const double appStart = 1.0;
    senderApp->SetStartTime(Seconds(appStart));
    receiverApp->SetStartTime(Seconds(0.5));
    senderApp->SetStopTime(Seconds(cfg.simTime + 2.0));
    receiverApp->SetStopTime(Seconds(cfg.simTime + 2.0));
    Simulator::Schedule(Seconds(cfg.simTime), &GameServer::StopEncoding, senderApp);

    /*
     * FlowMonitor 只能识别 IP 流，因此仅安装在 UDP 路径上。
     * L2 路径通过应用日志反映其性能。
     */
    Ptr<FlowMonitor> monitor;
    FlowMonitorHelper flowmon;
    if (!useL2)
    {
        monitor = flowmon.InstallAll();
    }

    Ptr<OutputStreamWrapper> phyTrace = ascii.CreateFileStream(paths.phyTrace);
    phy.EnableAsciiAll(phyTrace);

    /* ---------- 参数概览 ---------- */
    NS_LOG_UNCOND("Starting simulation (" << title << "):");
    NS_LOG_UNCOND("  FEC Policy: " << cfg.fecPolicyName);
    NS_LOG_UNCOND("  CC Algo: " << cfg.ccAlgo);
    NS_LOG_UNCOND("  Bitrate: " << cfg.bitrateBps << " bps");
    NS_LOG_UNCOND("  Wi-Fi Standard: " << cfg.wifiStandard);
    NS_LOG_UNCOND("  Channel Width: " << channelWidth << " MHz");
    NS_LOG_UNCOND("  Transport: " << transport);
    NS_LOG_UNCOND("  Output Dir: " << paths.dir);
    NS_LOG_UNCOND("  Duration: " << cfg.simTime << " s");

    if (useL2)
    {
        NS_LOG_UNCOND("L2 transport mode enabled: IP stack is not installed, "
                      "traffic is carried over raw 802.11 frames (EtherType 0x"
                      << std::hex << RTC_L2_ETHERTYPE << std::dec << ").");
        NS_LOG_UNCOND("  Sender MAC: " << senderMac << ", receiver MAC: " << receiverMac);

        /*
         * 对被验证性质的健全性检查：在 L2 设计下，任何节点上都不应该聚合有
         * IPv4/IPv6 对象，而应该具备 PacketSocketFactory。
         */
        for (uint32_t i = 0; i < wifiStaNodes.GetN(); i++)
        {
            Ptr<Node> node = wifiStaNodes.Get(i);
            NS_ABORT_MSG_IF(node->GetObject<Ipv4>() != nullptr,
                            "Ipv4 is unexpectedly installed on node " << node->GetId());
            NS_ABORT_MSG_IF(node->GetObject<Ipv6>() != nullptr,
                            "Ipv6 is unexpectedly installed on node " << node->GetId());
            NS_ABORT_MSG_IF(node->GetObject<PacketSocketFactory>() == nullptr,
                            "PacketSocketFactory is missing on node " << node->GetId());
        }
        NS_LOG_UNCOND("  Verification: no Ipv4/Ipv6 object on the nodes, "
                      "PacketSocketFactory is present.");
        NS_LOG_UNCOND("  Sender device count: " << wifiStaNodes.Get(0)->GetNDevices()
                      << " (no loopback, so no IP layer)");
    }

    /* ---------- 运行仿真 ---------- */
    Simulator::Stop(Seconds(cfg.simTime + 2.5));
    Simulator::Run();

    if (!useL2)
    {
        monitor->CheckForLostPackets();
        Ptr<Ipv4FlowClassifier> classifier =
            DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
        FlowMonitor::FlowStatsContainer stats = monitor->GetFlowStats();

        for (const auto& f : stats)
        {
            const FlowMonitor::FlowStats& s = f.second;
            Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(f.first);
            if (t.destinationAddress != receiverIp || t.destinationPort != cfg.appPort)
            {
                continue;
            }

            const uint64_t lost = (s.txPackets >= s.rxPackets) ? (s.txPackets - s.rxPackets) : 0;
            const double rxDuration =
                s.timeLastRxPacket.GetSeconds() - s.timeFirstTxPacket.GetSeconds();
            const double throughputMbps =
                (rxDuration > 0.0) ? (s.rxBytes * 8.0 / rxDuration / 1e6) : 0.0;
            const double meanDelayMs =
                (s.rxPackets > 0) ? (s.delaySum.GetSeconds() * 1000.0 / s.rxPackets) : 0.0;

            NS_LOG_UNCOND("Flow: " << t.sourceAddress << " -> " << t.destinationAddress);
            NS_LOG_UNCOND("  Tx Packets: " << s.txPackets);
            NS_LOG_UNCOND("  Tx Bytes:   " << s.txBytes);
            NS_LOG_UNCOND("  Rx Packets: " << s.rxPackets);
            NS_LOG_UNCOND("  Rx Bytes:   " << s.rxBytes);
            NS_LOG_UNCOND("  Lost Packets: " << lost);
            NS_LOG_UNCOND("  Throughput: " << throughputMbps << " Mbps");
            NS_LOG_UNCOND("  Delay Mean: " << meanDelayMs << " ms");
        }
    }

    Simulator::Destroy();

    /* 解析前先释放并关闭日志文件，确保缓冲区内容已写入磁盘。 */
    fecStream = nullptr;
    appStream = nullptr;
    debugStream = nullptr;
    phyTrace = nullptr;

    const rtcstats::Summary summary = rtcstats::ParseAppLog(paths.app);
    rtcstats::PrintAppLogSummary(summary, transport, paths.app);
    rtcstats::AppendSummaryFile(paths.summary, title, transport, paths.app, summary);

    return summary;
}

} // namespace rtcwifi

#endif /* RTC_WIFI_COMMON_H */
