/*
 * wifi-rtc-demo.cc
 *
 * Mode A —— 带完整协议栈（IPv4 + UDP）的 SparkRTC over Wi-Fi。
 *
 * 拓扑：  STA(发送端)  <-->  AP  <-->  STA(接收端)
 *
 * 这是参照路径：RTC 负载像原始的 wifi-rtc-demo 一样，装在 IPv4 之上的
 * UDP 数据报中传输。它的存在是为了给 wifi-rtc-l2.cc 的 L2 设计提供一个
 * 基线，二者仅传输方式不同。
 *
 * 产物写入 scratch/rtc-test/，文件名带 "udp-" 前缀，因此三个脚本
 * （A / B / AB）的结果可以并排比较。
 *
 * 用法：
 *   ./ns3 run "wifi-rtc-demo --simTime=30 --fecPolicy=webrtc --ccAlgo=none --bitrate=10000000"
 */

#include "rtc-wifi-common.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("WifiRtcModeA");

int
main(int argc, char* argv[])
{
    LogComponentEnable("WifiRtcModeA", LOG_LEVEL_INFO);

    rtcwifi::Config cfg;

    CommandLine cmd(__FILE__);
    rtcwifi::AddOptions(cmd, cfg);
    cmd.Parse(argc, argv);

    rtcwifi::Run(cfg, TRANSPORT_UDP, "Mode A");

    return 0;
}
